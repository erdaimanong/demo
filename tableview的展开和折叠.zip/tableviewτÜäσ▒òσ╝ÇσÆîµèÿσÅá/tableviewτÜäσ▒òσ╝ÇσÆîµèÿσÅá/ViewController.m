//
//  ViewController.m
//  tableview的展开和折叠
//
//  Created by 刘威成 on 16/4/6.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "ViewController.h"
#import "FoldCell.h"
#import "FoleModel.h"
@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,strong)UITableView *tableVIew;

@property(nonatomic,strong)NSMutableArray *dataArray;

@end

@implementation ViewController

- (NSMutableArray *)dataArray{
    
    if (_dataArray ==nil) {
        
        _dataArray = [NSMutableArray array];
    }
    
    return _dataArray;
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    _tableVIew = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    
    _tableVIew.delegate = self;
    
    _tableVIew.dataSource = self;
    
    [self.view  addSubview:_tableVIew];
    
    [_tableVIew registerClass:[FoldCell class] forCellReuseIdentifier:@"fold"];
    
    
    for (int i = 0; i<10; i++) {
        
        FoleModel *model = [[FoleModel  alloc]init];
   
//        分区头视图的内容
        model.name = [NSString stringWithFormat:@"第%d个分区",i];
        
        for (int j = 0; j< 10; j++) {
            
//            cell上的内容
            [model.array  addObject:[NSString  stringWithFormat:@"%d-----%d",i,j]];
        }
        
        [self.dataArray  addObject:model];
        
        [self.tableVIew  reloadData];
    }
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    FoleModel *model = [self.dataArray  objectAtIndex:section];
    
    if (model.isShow ==YES) {
        
        return  model.array.count;
    }else{
    
    return 0;
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
 return self.dataArray.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 40;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    FoleModel *model = [self.dataArray  objectAtIndex:section];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    btn.frame = CGRectMake(0, 0, self.view.frame.size.width, 40);
    
    btn.backgroundColor = [UIColor blueColor];
    
    btn.tag = section;
    
    [btn setTitle:model.name forState:UIControlStateNormal];
    
    [btn  addTarget:self action:@selector(fold_or_unfold:) forControlEvents:UIControlEventTouchUpInside];
    
    return btn;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    
    return 60;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell  *cell = [tableView  dequeueReusableCellWithIdentifier:@"fold"];
    
    if (!cell) {
        
    cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"fold"];
        
    }
    
    FoleModel *model = [self.dataArray  objectAtIndex:indexPath.section];
    
    cell.textLabel.text = [model.array objectAtIndex:indexPath.section];
    
    return cell;
}
- (void)fold_or_unfold:(UIButton *)btn{
    
    FoleModel *model = [self.dataArray  objectAtIndex:btn.tag];
    
    if (model.isShow == YES) {
        
        [model setIsShow:NO];
        
    }else{
        
        [model setIsShow:YES];
    }
    /**
     *    [self.tableVIew  reloadSections:[NSIndexSet  indexSetWithIndex:btn.tag] withRowAnimation:UITableViewRowAnimationFade];此方法用来刷新tableview的局部数据
     */
    [self.tableVIew  reloadSections:[NSIndexSet  indexSetWithIndex:btn.tag] withRowAnimation:UITableViewRowAnimationFade];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
