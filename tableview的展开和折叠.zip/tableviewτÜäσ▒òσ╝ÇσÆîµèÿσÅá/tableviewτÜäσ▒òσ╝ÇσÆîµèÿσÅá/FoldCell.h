//
//  FoldCell.h
//  tableview的展开和折叠
//
//  Created by 刘威成 on 16/4/6.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FoldCell : UITableViewCell

@end
