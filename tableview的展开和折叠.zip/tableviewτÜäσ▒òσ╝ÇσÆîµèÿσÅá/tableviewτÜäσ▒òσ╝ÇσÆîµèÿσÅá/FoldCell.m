//
//  FoldCell.m
//  tableview的展开和折叠
//
//  Created by 刘威成 on 16/4/6.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "FoldCell.h"

@implementation FoldCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}


-  (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    
    if (self == [super  initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        UILabel *nameLabel = [[UILabel alloc]initWithFrame:CGRectMake(15, 15, self.contentView.frame.size.width, 20)];
        
        nameLabel.textAlignment = NSTextAlignmentCenter;
        
        nameLabel.textColor = [UIColor redColor];
        
        [self.contentView  addSubview:nameLabel];
        
    }
    
    return self;
}

@end
