//
//  FoleModel.h
//  tableview的展开和折叠
//
//  Created by 刘威成 on 16/4/6.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FoleModel : NSObject

@property(nonatomic,strong)NSMutableArray *array;// 每组的数据

@property(nonatomic,copy)NSString *name;// 组名

@property(nonatomic,assign)BOOL isShow;// 组的状态，yes显示组，no不显示组

@end
