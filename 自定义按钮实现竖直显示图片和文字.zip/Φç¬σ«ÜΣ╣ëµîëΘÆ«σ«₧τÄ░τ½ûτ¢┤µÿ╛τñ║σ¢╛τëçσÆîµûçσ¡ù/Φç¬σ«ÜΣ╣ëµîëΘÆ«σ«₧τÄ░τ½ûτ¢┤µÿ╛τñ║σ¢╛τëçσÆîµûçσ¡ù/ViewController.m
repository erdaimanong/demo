//
//  ViewController.m
//  自定义按钮实现竖直显示图片和文字
//
//  Created by 刘威成 on 16/5/16.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "ViewController.h"
#import "UIButton+Extension.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];

    
    /**
     *  方式一
     */
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    btn.frame = CGRectMake(100, 100, 130, 130);
    
    [btn setImage:[UIImage imageNamed:@"icon_share"] forState:UIControlStateNormal];
    
    [btn setTitle:@"文字" forState:UIControlStateNormal];
    
    [btn verticalImageAndTitle:15];
    
    [self.view addSubview:btn];
    
    /**
     *  方式二
     */
    UIButton *button = [UIButton buttonWithFrame:CGRectMake(100, 300,120, 120) setImage:[UIImage imageNamed:@"icon_share"] steTitle:@"首页"  font:[UIFont systemFontOfSize:16] imageEdgeInset:UIEdgeInsetsMake(5,15,25,15)titleEdgeInset:UIEdgeInsetsMake(90, -90, 0, 0)];
    [self.view addSubview:button];
    
//    左右显示
    UIButton *button1 = [UIButton buttonWithFrame:CGRectMake(100, 500,180, 120) setImage:[UIImage imageNamed:@"icon_share"] steTitle:@"首页"  font:[UIFont systemFontOfSize:16] imageEdgeInset:UIEdgeInsetsMake(15,5,15,120-95)titleEdgeInset:UIEdgeInsetsMake(15, 5, 0, 0)];
    
    [self.view addSubview:button1];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
