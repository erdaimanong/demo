//
//  UIButton+Extension.m
//  自定义按钮实现竖直显示图片和文字
//
//  Created by 刘威成 on 16/5/16.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "UIButton+Extension.h"

@implementation UIButton (Extension)

- (void)verticalImageAndTitle:(CGFloat)spacing{
    self.titleLabel.backgroundColor = [UIColor greenColor];
    CGSize imageSize = self.imageView.frame.size;
    CGSize titleSize = self.titleLabel.frame.size;
    CGSize textSize = [self.titleLabel.text sizeWithFont:self.titleLabel.font];
    CGSize frameSize = CGSizeMake(ceilf(textSize.width), ceilf(textSize.height));
    if (titleSize.width + 0.5 < frameSize.width) {
        titleSize.width = frameSize.width;
    }
    CGFloat totalHeight = (imageSize.height + titleSize.height + spacing);
    self.imageEdgeInsets = UIEdgeInsetsMake(- (totalHeight - imageSize.height), 0.0, 0.0, - titleSize.width);
    self.titleEdgeInsets = UIEdgeInsetsMake(0, - imageSize.width, - (totalHeight - titleSize.height), 0);
}

+(UIButton *)buttonWithFrame:(CGRect)frame setImage:(UIImage *)image steTitle:(NSString *)title  font:(UIFont *)font imageEdgeInset:(UIEdgeInsets)edge titleEdgeInset:(UIEdgeInsets)edges{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];//button的类型
    button.frame = frame;//button的frame
    button.backgroundColor = [UIColor cyanColor];//button的背景颜色

    
    //    在UIButton中有三个对EdgeInsets的设置：ContentEdgeInsets、titleEdgeInsets、imageEdgeInsets
    [button setImage:image forState:UIControlStateNormal];//给button添加image
    
    button.imageEdgeInsets = edge;//设置image在button上的位置（上top，左left，下bottom，右right）这里可以写负值，对上写－5，那么image就象上移动5个像素
    
    [button setTitle:title forState:UIControlStateNormal];//设置button的title
    button.titleLabel.font = font;//title字体大小
    button.titleLabel.textAlignment = NSTextAlignmentCenter;//设置title的字体居中
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];//设置title在一般情况下为白色字体
    [button setTitleColor:[UIColor grayColor] forState:UIControlStateHighlighted];//设置title在button被选中情况下为灰色字体
    
    button.titleEdgeInsets = edges;//设置title在button上的位置（上top，左left，下bottom，右right）
    button.titleLabel.textAlignment = NSTextAlignmentCenter;

    
    return button;
}
@end
