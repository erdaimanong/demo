//
//  ViewController.m
//  导航条颜色渐变
//
//  Created by 刘威成 on 16/4/7.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationBar (category)
/**
 *  自定义导航栏上的view
 */
@property (nonatomic,strong) UIView * alphaView;

/**
 *  给外界一个方法，来改变颜色
 */
-(void)alphaNavigationBarView:(UIColor *)color;
@end
