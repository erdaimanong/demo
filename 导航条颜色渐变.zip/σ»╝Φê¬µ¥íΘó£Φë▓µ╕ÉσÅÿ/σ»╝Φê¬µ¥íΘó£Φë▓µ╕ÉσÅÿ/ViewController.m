//
//  ViewController.m
//  导航条颜色渐变
//
//  Created by 刘威成 on 16/4/7.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "ViewController.h"

#import "UINavigationBar+category.h"

@interface ViewController ()<UIScrollViewDelegate,UITableViewDataSource,UITableViewDelegate>

@property(nonatomic,strong)UITableView *tableview;

@property(nonatomic,strong)UIScrollView *scrollview;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
 
    self.navigationItem.title = @"主页";
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    [self  createUI];
    /**
     *  由于UITableview是继承于UIScrollView的、所以、同样可以使用同一个代理方法去实现tableview上的导航条的颜色渐变
     */
//    [self  createTableview];
    
}
/*
- (void)createTableview{
    
    self.tableview = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height-64) style:UITableViewStylePlain];
    
    self.tableview.delegate = self;
    
    self.tableview.dataSource = self;
    
    [self.view  addSubview:self.tableview];
    
}
#pragma tableview
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return 20;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 70;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static  NSString *cellID = @"cells";
    
    UITableViewCell *cell = [tableView  dequeueReusableCellWithIdentifier:cellID];
    
    if (!cell) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
    }
    
    
    return cell;
}
*/
#pragma scrollview
- (void)createUI{
    
    self.scrollview = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height-64)];
    
    self.scrollview.delegate = self;
    
    [self.view  addSubview:self.scrollview];
    
    for (int i= 0; i < 20; i++) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        
        btn.frame = CGRectMake(0, i*10+60*i, self.view.frame.size.width, 60);
        
        [btn  setBackgroundColor: [UIColor  brownColor]];
        
        [btn setTitle:[NSString  stringWithFormat:@"第%d个按钮",i] forState:UIControlStateNormal];
        
        [self.scrollview  addSubview:btn];
    }
    
    self.scrollview.contentSize = CGSizeMake(0, 20*70);
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    
    //拿到y值
    CGFloat contentOffY = scrollView.contentOffset.y;
    UIColor *color = [UIColor greenColor];
    
    CGFloat alpah =(self.view.frame.size.height -contentOffY)/self.view.frame.size.height;
    
    if (contentOffY > 0) {
        [self.navigationController.navigationBar alphaNavigationBarView:[color colorWithAlphaComponent:alpah]];
    }else{
        [self.navigationController.navigationBar alphaNavigationBarView:[color colorWithAlphaComponent:1]];
    }

}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
