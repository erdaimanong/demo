//
//  nav-webViewController.m
//  WKwebview
//
//  Created by 刘威成 on 16/5/19.
//  Copyright © 2016年 WEICHENG-LIU. All rights reserved.
//

#import "navwebViewController.h"

@interface navwebViewController ()<UIWebViewDelegate,UIActionSheetDelegate>

@property(nonatomic,strong)UIWebView *webView;

@property(nonatomic,strong)UIProgressView *progressView;

@property (assign, nonatomic) NSUInteger loadCount;

@end

@implementation navwebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self  createUI];
}

- (void)createUI{
    
    UIProgressView *progressView = [[UIProgressView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 0)];
    
    progressView.tintColor = [UIColor redColor];
    
    progressView.trackTintColor = [UIColor  whiteColor];
    
    [self.view  addSubview:progressView];
    
    self.progressView = progressView;
    
    UIWebView *webview = [[UIWebView alloc]initWithFrame:self.view.bounds];
    
    webview.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    
    webview.scalesPageToFit = YES;
    
    webview.backgroundColor = [UIColor whiteColor];
    
    webview.delegate = self;
    
    [self.view  insertSubview:webview belowSubview:progressView];
    
    NSURLRequest *request = [NSURLRequest  requestWithURL:[NSURL  URLWithString:@"http://m.jd.com/"]];
    
    [webview loadRequest:request];
    
    self.webView = webview;
    
    //取消右侧，下侧滚动条，
    for (UIView *_aView in [webview subviews]){
        
        if ([_aView isKindOfClass:[UIScrollView class]]){
            
            //右侧的滚动条
            [(UIScrollView *)_aView setShowsVerticalScrollIndicator:NO];
            
            //下侧的滚动条
            // [(UIScrollView *)_aView setShowsHorizontalScrollIndicator:NO];
            
            //去处上下滚动边界的黑色背景( //上下滚动出边界时的黑色的图片)
            for (UIView *_inScrollview in _aView.subviews){
                
                if ([_inScrollview isKindOfClass:[UIImageView class]]){
                    
                    _inScrollview.hidden = YES;
                }
            }
        }
    }
    
    [self  configBackItem];
    
    [self configMenuItem];

}

- (void)configBackItem {
    
    // 导航栏的返回按钮
    UIImage *backImage = [UIImage imageNamed:@"cc_webview_back"];
    backImage = [backImage imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 25, 22)];
    [backBtn setTintColor:[UIColor redColor]];
    [backBtn setBackgroundImage:backImage forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(backBtnPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *colseItem = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
    self.navigationItem.leftBarButtonItem = colseItem;
}

- (void)configMenuItem {
    
    // 导航栏的菜单按钮
    UIImage *menuImage = [UIImage imageNamed:@"cc_webview_menu"];
    menuImage = [menuImage imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    UIButton *menuBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 5, 20)];
    [menuBtn setTintColor:[UIColor redColor]];
    [menuBtn setImage:menuImage forState:UIControlStateNormal];
    [menuBtn addTarget:self action:@selector(menuBtnPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *menuItem = [[UIBarButtonItem alloc] initWithCustomView:menuBtn];
    self.navigationItem.rightBarButtonItem = menuItem;
}

- (void)configColseItem {
    
    // 导航栏的关闭按钮
    UIButton *colseBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 44, 44)];
    [colseBtn setTitle:@"关闭" forState:UIControlStateNormal];
    [colseBtn setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    [colseBtn addTarget:self action:@selector(colseBtnPressed:) forControlEvents:UIControlEventTouchUpInside];
    [colseBtn sizeToFit];
    
    UIBarButtonItem *colseItem = [[UIBarButtonItem alloc] initWithCustomView:colseBtn];
    NSMutableArray *newArr = [NSMutableArray arrayWithObjects:self.navigationItem.leftBarButtonItem,colseItem, nil];
    self.navigationItem.leftBarButtonItems = newArr;
}

#pragma mark - 普通按钮事件

// 返回按钮点击
- (void)backBtnPressed:(id)sender {
           if (self.webView.canGoBack) {
            [self.webView goBack];
            if (self.navigationItem.leftBarButtonItems.count == 1) {
                [self configColseItem];
            }
        }else {
            [self.navigationController popViewControllerAnimated:YES];
        }
}

// 菜单按钮点击
- (void)menuBtnPressed:(id)sender {
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"safari打开",@"复制链接",@"分享",@"刷新", nil];
    [actionSheet showInView:self.view];
}

// 关闭按钮点击
- (void)colseBtnPressed:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - 菜单按钮事件

- (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex {
    
    NSURL *url = [NSURL URLWithString:@"http://m.jd.com/"];
    
    NSString *urlStr = url.absoluteString;

    urlStr = self.webView.request.URL.absoluteString;
    
    if (buttonIndex == 0) {
        
        // safari打开
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlStr]];
    }else if (buttonIndex == 1) {
        
        // 复制链接
        if (urlStr.length > 0) {
            [[UIPasteboard generalPasteboard] setString:urlStr];
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"已复制链接到黏贴板" message:nil delegate:nil cancelButtonTitle:nil otherButtonTitles:@"知道了", nil];
            [alertView show];
        }
    }else if (buttonIndex == 2) {
        
        // 分享
        //[self.wkWebView evaluateJavaScript:@"这里写js代码" completionHandler:^(id reponse, NSError * error) {
        //NSLog(@"返回的结果%@",reponse);
        //}];
        NSLog(@"这里自己写，分享url：%@",urlStr);
    }else if (buttonIndex == 3) {
        
        // 刷新
    [self.webView reload];
        
    }
}

#pragma mark - webView代理

// 计算webView进度条
- (void)setLoadCount:(NSUInteger)loadCount {
    loadCount = loadCount;
    if (loadCount == 0) {
        self.progressView.hidden = YES;
        [self.progressView setProgress:0 animated:NO];
    }else {
        self.progressView.hidden = NO;
        CGFloat oldP = self.progressView.progress;
        CGFloat newP = (1.0 - oldP) / (loadCount + 1) + oldP;
        if (newP > 0.95) {
            newP = 0.95;
        }
        [self.progressView setProgress:newP animated:YES];
    }
}

- (void)webViewDidStartLoad:(UIWebView *)webView {
    self.loadCount ++;
}

- (void)webViewDidFinishLoad:(UIWebView *)webView {
    self.loadCount --;

    
//    注意： 从网络上获取数据，如果不想看到某种效果，并且网页存放在服务器端，里面的JS和Html代码，没有办法修改，可以在UIWebView的代理方法执行JS代码，去掉不想看到的效果。
    /*
        NSMutableString *js1 = [NSMutableString string];
        // 0.删除顶部的导航条
        [js1 appendString:@"var header = document.getElementsByTagName('header')[0];"];
        [js1 appendString:@"header.parentNode.removeChild(header);"];
        
        // 1.删除底部的链接
        [js1 appendString:@"var footer = document.getElementsByTagName('footer')[0];"];
        [js1 appendString:@"footer.parentNode.removeChild(footer);"];
        [webView stringByEvaluatingJavaScriptFromString:js1];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            NSMutableString *js2 = [NSMutableString string];
            // 2.删除浮动的广告
            [js2 appendString:@"var list = document.body.childNodes;"];
            [js2 appendString:@"var len = list.length;"];
            [js2 appendString:@"var banner = list[len - 1];"];
            [js2 appendString:@"banner.parentNode.removeChild(banner);"];
            [webView stringByEvaluatingJavaScriptFromString:js2];

        });
     */
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error {
    self.loadCount --;
}


@end
