//
//  ViewController.m
//  WKwebview
//
//  Created by 刘威成 on 16/5/19.
//  Copyright © 2016年 WEICHENG-LIU. All rights reserved.
//

#import "ViewController.h"

#import "basicWebViewController.h"

#import "basicWKwebViewController.h"

#import "navwebViewController.h"

#import "navwkwebViewController.h"

#import "jswebViewController.h"

#import "jswkwebViewController.h"

#import "webjsbridgeViewController.h"

#import "wkwebbridgeViewController.h"



@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)UITableView *tableView;

@property(nonatomic,strong)NSArray *dataArr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self initData];
    
    [self  createUI];
    
}

- (void)createUI{
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height-64) style:UITableViewStylePlain];
    
    _tableView.delegate = self;
    
    _tableView.dataSource = self;
    
    [self.view addSubview:_tableView];
    
}

- (void)initData{
    
    _dataArr = @[@"webview的基本使用",@"wkwebview的基本使用",@"webview加导航条",@"wkwebview加导航条",@"webview与js的相互调用",@"wekwebview与js的相互调用",@"web-jsBridge的使用",@"wk-jsBridge的使用"];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return _dataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cellID = @"cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        
        cell.textLabel.text = _dataArr[indexPath.row];
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section == 0) {
        
        if (indexPath.row == 0) {
            
            basicWebViewController *basicweb = [[basicWebViewController alloc]init];
            
            basicweb.navigationItem.title = self.dataArr[indexPath.row];
            
            [self.navigationController pushViewController:basicweb animated:YES];
            
        }else if (indexPath.row ==1){
            
            basicWKwebViewController *basicwk = [[basicWKwebViewController alloc]init];
            
             basicwk.navigationItem.title = self.dataArr[indexPath.row];
            
            [self.navigationController pushViewController:basicwk animated:YES];
            
        }else if (indexPath.row ==2){
            
            navwebViewController *navweb = [[navwebViewController alloc]init];
            
             navweb.navigationItem.title = self.dataArr[indexPath.row];
            
            [self.navigationController pushViewController:navweb animated:YES];
            
        }else if (indexPath.row == 3){
            
            navwkwebViewController *navwk = [[navwkwebViewController alloc]init];
            
            [self.navigationController  pushViewController:navwk animated:YES];
            
        }else if (indexPath.row == 4){
            
            jswebViewController *jsweb = [[jswebViewController alloc]init];
            
             jsweb.navigationItem.title = self.dataArr[indexPath.row];
            
            [self.navigationController pushViewController:jsweb animated:YES];
            
        }else if (indexPath.row == 5){
            
            jswkwebViewController *jswk = [[jswkwebViewController alloc]init];
            
             jswk.navigationItem.title = self.dataArr[indexPath.row];
            
            [self.navigationController pushViewController:jswk animated:YES];
            
        }else if (indexPath.row == 6){
            
            webjsbridgeViewController *webjs = [[webjsbridgeViewController alloc]init];
            
            webjs.navigationItem.title = self.dataArr[indexPath.row];
            
            [self.navigationController pushViewController:webjs animated:YES];
            
        }else if (indexPath.row == 7){
            
            wkwebbridgeViewController *wkweb = [[wkwebbridgeViewController alloc]init];
            
            wkweb.navigationItem.title = self.dataArr[indexPath.row];
            
            [self.navigationController  pushViewController:wkweb animated:YES];
        }
        
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
