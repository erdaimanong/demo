//
//  web-wkweb的变化.h
//  WKwebview
//
//  Created by 刘威成 on 16/5/19.
//  Copyright © 2016年 WEICHENG-LIU. All rights reserved.
//

#ifndef web_wkweb____h
#define web_wkweb____h


#endif /* web_wkweb____h */
二者对比：
优点：加载速度  比UIWebView提升差不多一倍的, 内存使用上面,反而还少了一半。
缺点：WKWebView 不支持缓存 和   NSURLProtocol 拦截了



类比UIWebView，跟UIWebView的API对比，
增加的属性：
1、estimatedProgress 加载进度条，在IOS8之前我们是通过一个假的进度条来实现
2、backForwardList 表示historyList
3、WKWebViewConfiguration *configuration; 初始化webview的配置
增加的方法：
1、- (instancetype)initWithFrame:(CGRect)frame configuration:(WKWebViewConfiguration *)configuration
初始化
3、(WKNavigation *)goToBackForwardListItem:(WKBackForwardListItem *)item;
跳到历史的某个页面
第二、相同的属性和方法
goBack、goForward、canGoBack、canGoForward、stopLoading、loadRequest、scrollView
第三、被删去的属性和方法：
1、- (NSString *)stringByEvaluatingJavaScriptFromString:(NSString *)script;
在跟js交互时，我们使用这个API，目前WKWebView完档没有给出实现类似功能的API
2、无法设置缓存
在UIWebView，使用NSURLCache缓存，通过setSharedURLCache可以设置成我们自己的缓存，但WKWebView不支持NSURLCache
第四、delegate方法的不同
UIWebView支持的代理是UIWebViewDelegate，WKWebView支持的代理是WKNavigationDelegate和WKUIDelegate
WKNavigationDelegate主要实现了涉及到导航跳转方面的回调方法
WKUIDelegate主要实现了涉及到界面显示的回调方法：如WKWebView的改变和js相关内容
具体来说WKNavigationDelegate除了有开始加载、加载成功、加载失败的API外，还具有额外的三个代理方法：
1、- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:(WKNavigation *)navigation
这个代理是服务器redirect时调用
2、- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler
这个代理方法表示当客户端收到服务器的响应头，根据response相关信息，可以决定这次跳转是否可以继续进行。
3.- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
根据webView、navigationAction相关信息决定这次跳转是否可以继续进行,这些信息包含HTTP发送请求，如头部包含User-Agent,Accept