//
//  basicWebViewController.m
//  WKwebview
//
//  Created by 刘威成 on 16/5/19.
//  Copyright © 2016年 WEICHENG-LIU. All rights reserved.
//

#import "basicWebViewController.h"

@interface basicWebViewController ()<UIWebViewDelegate>

@property(nonatomic,strong)UIWebView *webView;

@property(nonatomic,strong)UIActivityIndicatorView *activityIndicator;

@end

@implementation basicWebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self  createUI];
}

- (void)createUI{
 //UIWebview是继承于UIView的、且遵守NScoding和scrollviewdelegate的
    
    _webView = [[UIWebView alloc]initWithFrame:self.view.frame];
    
    _webView.backgroundColor = [UIColor grayColor];
    
    _webView.scalesPageToFit = YES;//自动对页面进行缩放以适应屏幕
    
    _webView.detectsPhoneNumbers = YES;//自动检测网页上的电话号码，单击可以拨打
    
    _webView.dataDetectorTypes = YES;//设置某些数据变为链接形式，这个枚举可以设置如电话号、地址、邮箱等转化为链接
    
    _webView.allowsInlineMediaPlayback = YES;// 设置是否使用内联播放器播放视频
    
    _webView.mediaPlaybackRequiresUserAction = YES;//设置视频是否自动播放
  
    _webView.mediaPlaybackAllowsAirPlay = YES;//设置音频播放是否支持ari play功能
    
    _webView.suppressesIncrementalRendering = YES;//设置是否将数据加载入内存后渲染界面

    //禁止webview的滚动(方法一)
    _webView.scrollView.bounces = NO;
    
    //禁止webview的滚动(方法二)
    UIScrollView *scrollView = [[_webView subviews] objectAtIndex:0];
    
    scrollView.bounces = NO;
    
//    加载url
    NSURL *url = [NSURL URLWithString:@"https://baidu.com/"];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [_webView loadRequest:request];
   
    /**
     // 也可以加载一个本地资源:
     NSString *filePath = [[NSBundle mainBundle] pathForResource:@"xxx" ofType:@"js"];
     NSURL* url = [NSURL fileURLWithPath:filePath];//创建URL
     NSURLRequest *request = [NSURLRequest requestWithURL:url];//创建NSURLRequest
     [_webView loadRequest:request];//加载
     
     UIWebView 还支持将一个NSString对象作为源来加载、可以为其提供一个基础URL、来指导UIWebView对象如何跟随链接和加载远程资源：
     [webView loadHTMLString:myHTML baseURL:[NSURL URLWithString:@"https://baidu.com/"]];
     */
    

//    当网页的大小超出View的大小时候、将以翻页的效果展示
    /**
     UIWebPaginationModeUnpaginated,//不使用翻页效果
     UIWebPaginationModeLeftToRight,//将网页超出部分分页，从左向右进行翻页
     UIWebPaginationModeTopToBottom,//将网页超出部分分页，从上向下进行翻页
     UIWebPaginationModeBottomToTop,//将网页超出部分分页，从下向上进行翻页
     UIWebPaginationModeRightToLeft//将网页超出部分分页，从右向左进行翻页
     */
    _webView.paginationMode = UIWebPaginationModeTopToBottom;
    
    //设置每一页的长度
    _webView.pageLength = self.webView.frame.size.height;
    
    
    //设置每一页的间距
    _webView.gapBetweenPages = 20;
    
    
#pragma 去掉webView的滚动条以及滚动边界的黑色背景：
    //取消右侧，下侧滚动条，
    for (UIView *_aView in [_webView subviews]){
        
        if ([_aView isKindOfClass:[UIScrollView class]]){
            
            //右侧的滚动条
            [(UIScrollView *)_aView setShowsVerticalScrollIndicator:NO];
            
            //下侧的滚动条
            [(UIScrollView *)_aView setShowsHorizontalScrollIndicator:NO];
            
            //去处上下滚动边界的黑色背景( //上下滚动出边界时的黑色的图片)
            for (UIView *_inScrollview in _aView.subviews){
                
                if ([_inScrollview isKindOfClass:[UIImageView class]]){
                    
                    _inScrollview.hidden = YES;
                }
            }
        }
    }
    
    _webView.delegate = self;

    [self.view  addSubview:_webView];
    
    
}

#pragma webview的四个代理方法
//当网页视图被指示载入内容而得到通知、应当返回YES、这样会进行加载、通过导航类型参数可以得到请求发起的原因、可以是以下任意值：
/**
 UIWebViewNavigationTypeLinkClicked
 UIWebViewNavigationTypeFormSubmitted
 UIWebViewNavigationTypeBackForward
 UIWebViewNavigationTypeReload
 UIWebViewNavigationTypeFormResubmitted
 UIWebViewNavigationTypeOther
 */
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    
//    取消webView上的超级链接加载问题：
    if (navigationType==UIWebViewNavigationTypeLinkClicked) {
        return NO;
    }
    else {
        return YES;
    }
    
    return YES;
}
//当网页视图已经开始加载一个请求后、得到通知、
- (void)webViewDidStartLoad:(UIWebView *)webView{
    
    /**
   加载时候的添加一个加载动画
     */
    //创建UIActivityIndicatorView背底半透明View
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [view setTag:108];
    [view setBackgroundColor:[UIColor blackColor]];
    [view setAlpha:0.5];
    [self.view addSubview:view];
    
    _activityIndicator = [[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0.0f, 0.0f, 32.0f, 32.0f)];
    [_activityIndicator setCenter:view.center];
    [_activityIndicator setActivityIndicatorViewStyle:UIActivityIndicatorViewStyleWhite];
    [view addSubview:_activityIndicator];
    
    [_activityIndicator startAnimating];
    
}
//当网页视图结束加载一个请求之后、得到通知、
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    
    //获取webview的页数
    NSInteger count = _webView.pageCount;
    
    NSLog(@"%ld",(long)count);
    
//    获取UIWebView高度
        UIScrollView *scrollView = (UIScrollView *)[[webView subviews] objectAtIndex:0];
    
        CGFloat webViewHeight = [scrollView contentSize].height;
        
        CGRect newFrame = webView.frame;
    
        newFrame.size.height = webViewHeight;
    
        _webView.frame = newFrame;
    
    [_activityIndicator stopAnimating];
    
    UIView *view = (UIView*)[self.view viewWithTag:108];
    [view removeFromSuperview];
    
//    取消长按webView上的链接弹出actionSheet的问题：
    [webView stringByEvaluatingJavaScriptFromString:@"document.documentElement.style.webkitTouchCallout = 'none';"];
    
    NSLog(@"%@",[webView stringByEvaluatingJavaScriptFromString:@"document.title"]);//获取当前页面的title
    
    NSLog(@"%@",webView.request.URL.absoluteString);//获取webview所在的网址
    /**
     *  获取webview的内容
     */
    NSLog(@"%@",[webView stringByEvaluatingJavaScriptFromString:@"document.documentElement.innerHTML"]);
    
}
//当在请求加载中发生错误时、得到通知、会提供一个NSSError对象、以标识所发生错误类型、
- (void)webView:(UIWebView *)webView didFailLoadWithError:(nullable NSError *)error{
    
    [_activityIndicator stopAnimating];
    
    UIView *view = (UIView*)[self.view viewWithTag:108];
    
    [view removeFromSuperview];
    
    NSLog(@"%@",error.localizedDescription);
}

//    - (void)reload;//    重新加载数据
//    - (void)stopLoading;//    停止加载数据
//    - (void)goBack;//    返回上一级
//    - (void)goForward;//    跳转下一级
//    @property (nonatomic, readonly, getter=canGoBack) BOOL canGoBack;//    获取能否返回上一级
//    @property (nonatomic, readonly, getter=canGoForward) BOOL canGoForward;//    获取能否跳转下一级
//    @property (nonatomic, readonly, getter=isLoading) BOOL loading;//    获取是否正在加载数据
/*以上将在设置导航的时候用到*/

/*
IOS中UIWebView常用注意点：

与UIWebView进行交互，调用web页面中的需要传参的函数时，参数需要带单引号，或者双引号（双引号需要进行转义在转义字符前加\）,在传递json字符串时不需要加单引号或双引号：
-(void)webViewDidFinishLoad:(UIWebView *)webView{
 
    NSString *sendJsStr=[NSString stringWithFormat:@"openFile(\"%@\")",jsDocPathStr];
    [webView stringByEvaluatingJavaScriptFromString:sendJsStr];
}

在该代理方法中判断与webView的交互，可通过html里定义的协议实现：
- (BOOL)webView:(UIWebView*)webView shouldStartLoadWithRequest:(NSURLRequest*)request navigationType:(UIWebViewNavigationType)navigationType

为webView添加背景图片：
approvalWebView.backgroundColor=[UIColor clearColor];
approvalWebView.opaque=NO;//这句话很重要，webView是否是不透明的，no为透明 在webView下添加个imageView展示图片就可以了

获取webView页面内容信息：
NSString *docStr=[webView stringByEvaluatingJavaScriptFromString:@"document.documentElement.textContent"];//获取web页面内容信息，此处获取的是个json字符串
SBJsonParser *parserJson=[[[SBJsonParser alloc]init]autorelease];
NSDictionary *contentDic=[parserJson objectWithString:docStr];//将json字符串转化为字典

加载本地文件的方法：
//第一种方法：
NSString* path = [[NSBundle mainBundle] pathForResource:name ofType:@"html" inDirectory:@"mobile"];//mobile是根目录，name是文件名称，html是文件类型
[webView loadRequest:[NSURLRequest requestWithURL:[NSURL fileURLWithPath:path]]]; //加载本地文件
//第二种方法：
NSString *resourcePath = [[NSBundle mainBundle] resourcePath];
NSString *filePath = [resourcePath stringByAppendingPathComponent:@"mobile.html"];
NSString *htmlstring=[[NSString alloc] initWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
[uiwebview loadHTMLString:htmlstring baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];

将文件下载到本地址然后再用webView打开：
NSString *resourceDocPath = [[NSString alloc] initWithString:[[[[NSBundle mainBundle] resourcePath] stringByDeletingLastPathComponent] stringByAppendingPathComponent:@"Documents"]];
self.filePath = [resourceDocPath stringByAppendingPathComponent:[NSString stringWithFormat:@"maydoc%@",docType]];
NSData *attachmentData = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:theUrl]];
[attachmentData writeToFile:filePath atomically:YES];
NSURL *url = [NSURL fileURLWithPath:filePath];
NSURLRequest *requestObj = [NSURLRequest requestWithURL:url];
[attachmentWebView loadRequest:requestObj];
//删除指定目录下的文件
NSFileManager *magngerDoc=[NSFileManager defaultManager];
[magngerDoc removeItemAtPath:filePath error:nil];
 
 
处理webView展示txt文档乱码问题：
if ([theType isEqualToString:@".txt"]){
 
    //txt分带编码和不带编码两种，带编码的如UTF-8格式txt，不带编码的如ANSI格式txt
    //不带的，可以依次尝试GBK和GB18030编码
    NSString* aStr = [[NSString alloc] initWithData:attachmentData encoding:NSUTF8StringEncoding];
    if (!aStr)
    {
        //用GBK进行编码
        aStr=[[NSString alloc] initWithData:attachmentData encoding:0x80000632];
    }
    if (!aStr)
    {
        //用GBK编码不行,再用GB18030编码
        aStr=[[NSString alloc] initWithData:attachmentData encoding:0x80000631];
    }
    //通过html语言进行排版
    NSString* responseStr = [NSString stringWithFormat:
                             @""
                             ""
                             ""
                             ""
                             "%@"
                             "/pre>"
                             ""
                             "",
                             aStr];
    [attachmentWebView loadHTMLString:responseStr baseURL:[NSURL fileURLWithPath:[[NSBundle mainBundle] bundlePath]]];
    return;
}

//删除缓存的方法
//在使用webView进行新浪微博分享时，webView会自动保存登陆的cookie导致项目中的分享模块有些问题，删除 webView的cookie的方法：
 
-(void)deleteCookieForDominPathStr:(NSString *)thePath
{
    //删除本地cookie，thePath为cookie路径通过打印cookie可知道其路径
    for(NSHTTPCookie *cookie in [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies]) {
        
        if([[cookie domain] isEqualToString:thePath]) {
            
            [[NSHTTPCookieStorage sharedHTTPCookieStorage] deleteCookie:cookie];
        }
    }
}
 
 // 在OC中调用JS
 #pragma mark - UIWebViewDelegate
 - (void)webViewDidFinishLoad:(UIWebView *)webView
 {
 NSMutableString *js1 = [NSMutableString string];
 // 0.删除顶部的导航条
 [js1 appendString:@"var header = document.getElementsByTagName('header')[0];"];
 [js1 appendString:@"header.parentNode.removeChild(header);"];
 
 // 1.删除底部的链接
 [js1 appendString:@"var footer = document.getElementsByTagName('footer')[0];"];
 [js1 appendString:@"footer.parentNode.removeChild(footer);"];
 [webView stringByEvaluatingJavaScriptFromString:js1];
 
 dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.25 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
 NSMutableString *js2 = [NSMutableString string];
 // 2.删除浮动的广告
 [js2 appendString:@"var list = document.body.childNodes;"];
 [js2 appendString:@"var len = list.length;"];
 [js2 appendString:@"var banner = list[len - 1];"];
 [js2 appendString:@"banner.parentNode.removeChild(banner);"];
 [webView stringByEvaluatingJavaScriptFromString:js2];
 
 // 显示scrollView
 webView.scrollView.hidden = NO;
 
 // 删除圈圈
 [self.loadingView removeFromSuperview];
 });
 }
*/

@end
