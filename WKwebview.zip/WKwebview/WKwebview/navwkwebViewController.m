//
//  nav-wkwebViewController.m
//  WKwebview
//
//  Created by 刘威成 on 16/5/19.
//  Copyright © 2016年 WEICHENG-LIU. All rights reserved.
//

#import "navwkwebViewController.h"

#import <WebKit/WebKit.h>

#define  IOS8X  ([[UIDevice currentDevice].systemVersion floatValue]>=8.0)

#define WEBProgressView_color ([UIColor redColor])

@interface navwkwebViewController ()<UIActionSheetDelegate,WKNavigationDelegate>



@property(nonatomic,strong)UIProgressView *progressView;

@property(nonatomic,strong)WKWebView *wkWebVIew;

@property (assign, nonatomic) NSUInteger loadCount;

@end

@implementation navwkwebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self  createUI];
    
    [self  configBackItem];
    
    [self  configMenuItem];
}

- (void)createUI{
    
    
    UIProgressView *progressView = [[UIProgressView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 0)];
    
    progressView.tintColor = WEBProgressView_color;
    
    progressView.trackTintColor = [UIColor  whiteColor];
    
    [self.view  addSubview:progressView];
    
    self.progressView = progressView;
    
    if (IOS8X) {
        
        WKWebView *wkwebView = [[WKWebView alloc]initWithFrame:self.view.bounds];
        
        wkwebView.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
        
        wkwebView.backgroundColor = [UIColor whiteColor];
        
        wkwebView.navigationDelegate = self;
        
        [self.view  insertSubview:wkwebView belowSubview:progressView];
        
        [wkwebView  addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:nil];
        
        NSURL *url = [NSURL URLWithString:@"http://m.jd.com/"];
        
        NSURLRequest *request = [NSURLRequest  requestWithURL:url];
        
        [wkwebView  loadRequest:request];
        
        self.wkWebVIew = wkwebView;
        
        //取消右侧，下侧滚动条，
        for (UIView *_aView in [wkwebView subviews]){
            
            if ([_aView isKindOfClass:[UIScrollView class]]){
                
                //右侧的滚动条
                [(UIScrollView *)_aView setShowsVerticalScrollIndicator:NO];
                
                //下侧的滚动条
                // [(UIScrollView *)_aView setShowsHorizontalScrollIndicator:NO];
                
                //去处上下滚动边界的黑色背景( //上下滚动出边界时的黑色的图片)
                for (UIView *_inScrollview in _aView.subviews){
                    
                    if ([_inScrollview isKindOfClass:[UIImageView class]]){
                        
                        _inScrollview.hidden = YES;
                    }
                }
            }
        }
    }
}


- (void)configBackItem {
    
    // 导航栏的返回按钮
    UIImage *backImage = [UIImage imageNamed:@"cc_webview_back"];
    backImage = [backImage imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    UIButton *backBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 25, 22)];
    [backBtn setTintColor:WEBProgressView_color];
    [backBtn setBackgroundImage:backImage forState:UIControlStateNormal];
    [backBtn addTarget:self action:@selector(backBtnPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *colseItem = [[UIBarButtonItem alloc] initWithCustomView:backBtn];
    self.navigationItem.leftBarButtonItem = colseItem;
}

- (void)configMenuItem {
    
    // 导航栏的菜单按钮
    UIImage *menuImage = [UIImage imageNamed:@"cc_webview_menu"];
    menuImage = [menuImage imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate];
    UIButton *menuBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 5, 20)];
    [menuBtn setTintColor:WEBProgressView_color];
    [menuBtn setImage:menuImage forState:UIControlStateNormal];
    [menuBtn addTarget:self action:@selector(menuBtnPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    UIBarButtonItem *menuItem = [[UIBarButtonItem alloc] initWithCustomView:menuBtn];
    self.navigationItem.rightBarButtonItem = menuItem;
}

- (void)configColseItem {
    
    // 导航栏的关闭按钮
    UIButton *colseBtn = [[UIButton alloc]initWithFrame:CGRectMake(0, 0, 44, 44)];
    [colseBtn setTitle:@"关闭" forState:UIControlStateNormal];
    [colseBtn setTitleColor:WEBProgressView_color forState:UIControlStateNormal];
    [colseBtn addTarget:self action:@selector(colseBtnPressed:) forControlEvents:UIControlEventTouchUpInside];
    [colseBtn sizeToFit];
    
    UIBarButtonItem *colseItem = [[UIBarButtonItem alloc] initWithCustomView:colseBtn];
    NSMutableArray *newArr = [NSMutableArray arrayWithObjects:self.navigationItem.leftBarButtonItem,colseItem, nil];
    self.navigationItem.leftBarButtonItems = newArr;
}

#pragma mark - 普通按钮事件

// 返回按钮点击
- (void)backBtnPressed:(id)sender {
    if (IOS8X) {
        if (self.wkWebVIew.canGoBack) {
            [self.wkWebVIew goBack];
            if (self.navigationItem.leftBarButtonItems.count == 1) {
                [self configColseItem];
            }
        }else {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }

}

// 菜单按钮点击
- (void)menuBtnPressed:(id)sender {
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:@"safari打开",@"复制链接",@"分享",@"刷新", nil];
    [actionSheet showInView:self.view];
}

// 关闭按钮点击
- (void)colseBtnPressed:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - 菜单按钮事件

- (void)actionSheet:(UIActionSheet *)actionSheet didDismissWithButtonIndex:(NSInteger)buttonIndex {
    
    NSURL *url = [NSURL URLWithString:@"http://m.jd.com/"];
    
    NSString *urlStr = url.absoluteString;

    if (IOS8X) urlStr = self.wkWebVIew.URL.absoluteString;
    
    if (buttonIndex == 0) {
        
        // safari打开
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:urlStr]];
    }else if (buttonIndex == 1) {
        
        // 复制链接
        if (urlStr.length > 0) {
            [[UIPasteboard generalPasteboard] setString:urlStr];
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"已复制链接到黏贴板" message:nil delegate:nil cancelButtonTitle:nil otherButtonTitles:@"知道了", nil];
            [alertView show];
        }
    }else if (buttonIndex == 2) {
        
        // 分享
        //[self.wkWebView evaluateJavaScript:@"这里写js代码" completionHandler:^(id reponse, NSError * error) {
        //NSLog(@"返回的结果%@",reponse);
        //}];
        NSLog(@"这里自己写，分享url：%@",urlStr);
    }else if (buttonIndex == 3) {
        
        // 刷新
        if (IOS8X) [self.wkWebVIew reload];
        
    }
}

#pragma mark - wkWebView代理

// 如果不添加这个，那么wkwebview跳转不了AppStore
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    if ([webView.URL.absoluteString hasPrefix:@"https://itunes.apple.com"]) {
        [[UIApplication sharedApplication] openURL:navigationAction.request.URL];
        decisionHandler(WKNavigationActionPolicyCancel);
    }else {
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}

// 计算wkWebView进度条
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context {
    if (object == self.wkWebVIew && [keyPath isEqualToString:@"estimatedProgress"]) {
        CGFloat newprogress = [[change objectForKey:NSKeyValueChangeNewKey] doubleValue];
        if (newprogress == 1) {
            self.progressView.hidden = YES;
            [self.progressView setProgress:0 animated:NO];
        }else {
            self.progressView.hidden = NO;
            [self.progressView setProgress:newprogress animated:YES];
        }
    }
}

// 记得取消监听
- (void)dealloc {
    if (IOS8X) {
        [self.wkWebVIew removeObserver:self forKeyPath:@"estimatedProgress"];
    }
}

@end
