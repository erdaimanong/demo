//
//  LVmodel.h
//  WKwebview
//
//  Created by 刘威成 on 16/5/19.
//  Copyright © 2016年 WEICHENG-LIU. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <JavaScriptCore/JavaScriptCore.h>
#import <UIKit/UIKit.h>
@protocol JavaScriptObjectiveDelegate <JSExport>

//js调用此方法来调用的系统的相册的方法
- (void)callSystemCamera;

//在JS中调用时，函数名应该为showAlertMsg(arg1,arg2)
- (void)showAlert:(NSString *)title msg:(NSString *)msg;

//通过JSON传过来
-(void)callWithDict:(NSDictionary *)params;

//JS调用OC、然后再OC中通过调用JS方法来传值给JS
-(void)jsCallObjcAndObjcCallJsWithDict:(NSDictionary *)params;

@end

// 此模型用于注入JS的模型、这样就可以通过模型来调用方法、
@interface LVmodel : NSObject<JavaScriptObjectiveDelegate>

@property(nonatomic,weak)JSContext *jsContext;

@property(nonatomic,weak)UIWebView *webView;

@end
