//
//  basicWKwebViewController.m
//  WKwebview
//
//  Created by 刘威成 on 16/5/19.
//  Copyright © 2016年 WEICHENG-LIU. All rights reserved.
//

#import "basicWKwebViewController.h"

#import <WebKit/WebKit.h>
//WKWebview在IOS8以后可用
#define  IOS8X  ([[UIDevice currentDevice].systemVersion floatValue]>=8.0)

/**
 *  三大代理：
 WKNavigationDelegate，与页面导航加载相关
 WKUIDelegate，与JS交互时的ui展示相关，比较JS的alert、confirm、prompt
 WKUIDelegate可以把javascript的一些alert捕捉到，然后显示自定义的UI。
 WKScriptMessageHandler，与js交互相关，通常是ios端注入名称，js端通过window.webkit.messageHandlers.{NAME}.postMessage()来发消息到ios端
 */
@interface basicWKwebViewController ()<WKNavigationDelegate,WKUIDelegate,WKScriptMessageHandler>

@property(nonatomic,strong)WKWebView *wkWeb;

@end

@implementation basicWKwebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self  createUI];
}

- (void)createUI{
//    @interface WKWebView : UIView、wkwebview同样继承于UIView

    if (IOS8X) {
        
        WKWebViewConfiguration *configuration =[[WKWebViewConfiguration alloc]init];
        
        configuration.preferences.minimumFontSize = 11;
        
        configuration.preferences.javaScriptEnabled = YES;
        
        //默认是不能通过JS自动打开窗口的、必须通过用户交互才能打开
        configuration.preferences.javaScriptCanOpenWindowsAutomatically = YES;
        
        configuration.allowsInlineMediaPlayback = YES;// 设置是否使用内联播放器播放视频
        
        configuration.allowsAirPlayForMediaPlayback = YES;//设置音频播放是否支持ari play功能
      
        configuration.mediaPlaybackRequiresUserAction = YES;//设置视频是否自动播放
        
         configuration.suppressesIncrementalRendering = YES;//设置是否将数据加载入内存后渲染界面

//        @property (nonatomic, strong) WKUserContentController *userContentController;
//        
//        @property (nonatomic, strong) WKWebsiteDataStore *websiteDataStore NS_AVAILABLE(10_11, 9_0);
//     
//        @property (nonatomic) BOOL suppressesIncrementalRendering;
//    
//        @property (nullable, nonatomic, copy) NSString *applicationNameForUserAgent NS_AVAILABLE(10_11, 9_0);

//        @property (nonatomic) WKSelectionGranularity selectionGranularity;

        _wkWeb = [[WKWebView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) configuration:configuration];
        
        _wkWeb.backgroundColor = [UIColor grayColor];
        
        _wkWeb.scrollView.scrollEnabled = YES;
        
        //开启左滑回退
        _wkWeb.allowsBackForwardNavigationGestures = YES;
        
        [self.view addSubview:_wkWeb];
        
        NSURL *url = [NSURL URLWithString:@"http://m.jd.com/"];
        
        NSURLRequest *request = [NSURLRequest requestWithURL:url];
        
        [_wkWeb loadRequest:request];
        
    }else{
        
        [[[UIAlertView alloc]initWithTitle:@"提示" message:@"系统版本过低、不支持wk" delegate:self cancelButtonTitle:@"知道了" otherButtonTitles:nil, nil]show];
    }
}

#pragma  WKNavigationDelegate
//该代理提供的方法，可以用来追踪加载过程（页面开始加载、加载完成、加载失败）、决定是否执行跳转。
- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(WKNavigation *)navigation {
    // 类似UIWebView的 -webViewDidStartLoad:  页面开始加载时调用
    NSLog(@"didStartProvisionalNavigation");
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
}

- (void)webView:(WKWebView *)webView didCommitNavigation:(WKNavigation *)navigation {
    //内容开始返回时调用
    NSLog(@"didCommitNavigation");
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    // 类似 UIWebView 的 －webViewDidFinishLoad:  页面加载完成时调用
    NSLog(@"didFinishNavigation");

    if (webView.title.length > 0) {
        self.title = webView.title;
    }
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation
      withError:(NSError *)error {
    // 类似 UIWebView 的- webView:didFailLoadWithError:  页面加载失败时调用
    NSLog(@"didFailProvisionalNavigation");
}

- (void)webView:(WKWebView *)webView decidePolicyForNavigationResponse:(WKNavigationResponse *)navigationResponse
decisionHandler:(void (^)(WKNavigationResponsePolicy))decisionHandler {
    //这个代理方法表示当客户端收到服务器的响应头，根据response相关信息，可以决定这次跳转是否可以继续进行
    decisionHandler(WKNavigationResponsePolicyAllow);
}

- (void)webView:(WKWebView *)webView didReceiveServerRedirectForProvisionalNavigation:
(WKNavigation *)navigation{
    //接收到服务器跳转请求之后调用
}
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:
(WKNavigationAction *)navigationAction
decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler {
    // 类似 UIWebView 的 -webView: shouldStartLoadWithRequest: navigationType:
//    在发送请求之前，决定是否跳转
    NSLog(@"4.%@",navigationAction.request);
    NSString *url = [navigationAction.request.URL.absoluteString
                     stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    decisionHandler(WKNavigationActionPolicyAllow);
    
}
- (void)webView:(WKWebView *)webView didReceiveAuthenticationChallenge:(NSURLAuthenticationChallenge *)challenge
completionHandler:(void (^)(NSURLSessionAuthChallengeDisposition, NSURLCredential *))completionHandler {
    
}
#pragma WKUIDelegate

- (WKWebView *)webView:(WKWebView *)webView createWebViewWithConfiguration:(WKWebViewConfiguration *)configuration forNavigationAction:(WKNavigationAction *)navigationAction windowFeatures:(WKWindowFeatures *)windowFeatures {
    // 接口的作用是打开新窗口委托
//    [self createNewWebViewWithURL:webView.URL.absoluteString config:configuration];
//    
//    return currentSubView.webView;
    return  webView;
}
/*以下三个代理方法全都是与界面弹出提示框相关的，针对于web界面的三种提示框（警告框、确认框、输入框）分别对应三种代理方法 */
- (void)webView:(WKWebView *)webView runJavaScriptAlertPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)())completionHandler{
    // js 里面的alert实现，如果不实现，网页的alert函数无效
}

- (void)webView:(WKWebView *)webView runJavaScriptConfirmPanelWithMessage:(NSString *)message initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(BOOL))completionHandler {
    //  js 里面的alert实现，如果不实现，网页的alert函数无效  ,
}

- (void)webView:(WKWebView *)webView runJavaScriptTextInputPanelWithPrompt:(NSString *)prompte defaultText:(NSString *)defaultText initiatedByFrame:(WKFrameInfo *)frame completionHandler:(void (^)(NSString *))completionHandler {
    
    completionHandler(@"Client Not handler");
}

@end
