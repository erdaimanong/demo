//
//  wkwebbridgeViewController.h
//  WKwebview
//
//  Created by 刘威成 on 16/5/20.
//  Copyright © 2016年 WEICHENG-LIU. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface wkwebbridgeViewController : UIViewController

@end
