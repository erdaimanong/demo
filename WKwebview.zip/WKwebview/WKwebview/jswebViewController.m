//
//  js-webViewController.m
//  WKwebview
//
//  Created by 刘威成 on 16/5/19.
//  Copyright © 2016年 WEICHENG-LIU. All rights reserved.
//

#import "jswebViewController.h"
#import <JavaScriptCore/JavaScriptCore.h>
#import "LVmodel.h"
@interface jswebViewController ()<UIWebViewDelegate>

@property(nonatomic,strong)UIWebView *webview;

@property(nonatomic,strong)JSContext *jsContext;

@end

@implementation jswebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self  createUI];
}

/**
 *JSContext, JSContext是代表JS的执行环境，通过-evaluateScript:方法就可以执行一JS代码
 *JSValue, JSValue封装了JS与ObjC中的对应的类型，以及调用JS的API等
 *JSExport, JSExport是一个协议，遵守此协议，就可以定义我们自己的协议，在协议中声明的API都会在JS中暴露出来，才能调用
 */

- (void)createUI{
    
    _webview = [[UIWebView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    
    _webview.delegate = self;
    

    NSURL *url = [[NSBundle mainBundle] URLForResource:@"test" withExtension:@"html"];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [_webview loadRequest:request];
    
    [self.view  addSubview:_webview];
    
//    [self createFirstJS];
    
}
//直接调用JS代码
- (void)createFirstJS{
//    创建对象
    self.jsContext = [[JSContext alloc]init];
    
//    jscontext可以直接执行JS代码
    
    [self.jsContext evaluateScript:@"var num = 10"];
    
    [self.jsContext evaluateScript:@"var squareFunc = function(value){return value * value}"];
    
    //计算结果
    JSValue *squre = [self.jsContext evaluateScript:@"squareFunc(num)"];
    
    NSLog(@"%@",squre);
    
    // 也可以通过下标的方式获取到方法
    JSValue *squareFunc = self.jsContext[@"squareFunc"];
    
    JSValue *value = [squareFunc callWithArguments:@[@"120"]];

    NSLog(@"%@", value);
    
//    缺点：使用不太方便、
}

#pragma mark - UIWebViewDelegate

- (void)webViewDidStartLoad:(UIWebView *)webView{
    
    
}

-(void)webViewDidFinishLoad:(UIWebView *)webView{
    
    self.jsContext = [webView valueForKeyPath:@"documentView.webView.mainFrame.javaScriptContext"];
    // 通过模型调用方法，这种方式更好些。
    
    LVmodel *model  = [[LVmodel alloc] init];
    self.jsContext[@"OCModel"] = model;
    model.jsContext = self.jsContext;
    model.webView = self.webview;
    
    self.jsContext.exceptionHandler = ^(JSContext *context, JSValue *exceptionValue) {
        context.exception = exceptionValue;
        NSLog(@"异常信息：%@", exceptionValue);
    };
}

@end
