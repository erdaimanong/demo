//
//  AppDelegate.m
//  3DTouch
//
//  Created by 刘威成 on 16/5/18.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "AppDelegate.h"
#import "FirstViewController.h"
#import "secondViewController.h"
#import "thirdViewController.h"
#import "FourViewController.h"
#import "FiveViewController.h"
@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    self.window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    
    self.window.backgroundColor = [UIColor whiteColor];
    
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:[[FirstViewController alloc]init]];
    
    self.window.rootViewController = nav;
    
    [self.window makeKeyAndVisible];
    
#warning 提醒 -- 此次的3Dtouch采用的是静态标签和动态标签两种方法、短信的是静态方法
    
    [self  creatShortcutItem];
    
    
/***下面的方法是判断APP是否在后台运行、如果没有、则需要这个方法、如果在后台运行、这不需要***/    
      UIApplicationShortcutItem *shortcutItem = [launchOptions valueForKey:UIApplicationLaunchOptionsShortcutItemKey];
    
    //判断先前我们设置的快捷选项标签唯一标识，根据不同标识执行不同操作
    if([shortcutItem.type isEqualToString:@"com.mycompany.myapp.share"]){
        
        secondViewController *sec = [[secondViewController alloc]init];
        
        [nav pushViewController:sec animated:YES];
        
    }else if ([shortcutItem.type isEqualToString:@"com.mycompany.myapp.message"]) {
        
        thirdViewController *thrid = [[thirdViewController alloc]init];
        
        [nav pushViewController:thrid animated:NO];
        
    } else if ([shortcutItem.type isEqualToString:@"com.mycompany.myapp.love"]) {
        
        FourViewController *four = [[FourViewController alloc]init];
        
        [nav pushViewController:four animated:NO];
        
    }else if ([shortcutItem.type isEqualToString:@"com.mycompany.myapp.play"]){
        
        FiveViewController *five = [[FiveViewController alloc]init];
        
        [nav  pushViewController:five animated:YES];
    }
    
    
    return YES;
}

//创建应用图标上的3D touch快捷选项
- (void)creatShortcutItem {
    
    //    //创建自定义图标的icon
    //    UIApplicationShortcutIcon *icon2 = [UIApplicationShortcutIcon iconWithTemplateImageName:@"分享.png"];
    
/***************分享*****************/
    //创建系统风格的icon
    UIApplicationShortcutIcon *icon1 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeShare];

    //创建快捷选项
    UIApplicationShortcutItem * item1 = [[UIApplicationShortcutItem alloc]initWithType:@"com.mycompany.myapp.share" localizedTitle:@"分享" localizedSubtitle:@"快速分享" icon:icon1 userInfo:nil];
    
    
//    /***************短信*****************/
//    //创建系统风格的icon
//    UIApplicationShortcutIcon *icon2 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeMessage];
//    
//    //创建快捷选项
//    UIApplicationShortcutItem * item2 = [[UIApplicationShortcutItem alloc]initWithType:@"com.mycompany.myapp.message" localizedTitle:@"短信" localizedSubtitle:@"编写短信" icon:icon2 userInfo:nil];
    
    /***************收藏*****************/
    //创建系统风格的icon
    UIApplicationShortcutIcon *icon3 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypeLove];
    
    //创建快捷选项
    UIApplicationShortcutItem * item3 = [[UIApplicationShortcutItem alloc]initWithType:@"com.mycompany.myapp.love" localizedTitle:@"收藏" localizedSubtitle:@"查看我的收藏" icon:icon3 userInfo:nil];
    
    /***************快速打开*****************/
    //创建系统风格的icon
    UIApplicationShortcutIcon *icon4 = [UIApplicationShortcutIcon iconWithType:UIApplicationShortcutIconTypePlay];
    
    //创建快捷选项
    UIApplicationShortcutItem * item4 = [[UIApplicationShortcutItem alloc]initWithType:@"com.mycompany.myapp.play" localizedTitle:@"打开" localizedSubtitle:@"快速打开" icon:icon4 userInfo:nil];
    
    //添加到快捷选项数组
//    [UIApplication sharedApplication].shortcutItems = @[item1,item2,item3,item4];
    [UIApplication sharedApplication].shortcutItems = @[item1,item3,item4];
}

//如果app在后台、通过快捷选项标签进入App、则调用该方法、如果APP不在后台、已被杀死、则通过快捷选项标签进入app的逻辑在- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions中
- (void)application:(UIApplication *)application performActionForShortcutItem:(UIApplicationShortcutItem *)shortcutItem completionHandler:(void (^)(BOOL))completionHandler {
    
    UINavigationController *nav = [[UINavigationController alloc]initWithRootViewController:[[FirstViewController alloc]init]];
    
    self.window.rootViewController = nav;

    [self.window makeKeyAndVisible];
    
    //判断先前我们设置的快捷选项标签唯一标识，根据不同标识执行不同操作
    if([shortcutItem.type isEqualToString:@"com.mycompany.myapp.share"]){

        secondViewController *sec = [[secondViewController alloc]init];
        
        [nav pushViewController:sec animated:YES];
        
    }else if ([shortcutItem.type isEqualToString:@"com.mycompany.myapp.message"]) {
        
        thirdViewController *thrid = [[thirdViewController alloc]init];
        
        [nav pushViewController:thrid animated:NO];
        
    } else if ([shortcutItem.type isEqualToString:@"com.mycompany.myapp.love"]) {
        
        FourViewController *four = [[FourViewController alloc]init];
        
        [nav pushViewController:four animated:NO];
        
    }else if ([shortcutItem.type isEqualToString:@"com.mycompany.myapp.play"]){
        
        FiveViewController *five = [[FiveViewController alloc]init];
        
        [nav  pushViewController:five animated:YES];
    }
    
    if (completionHandler) {
        
        completionHandler(YES);
    }
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
