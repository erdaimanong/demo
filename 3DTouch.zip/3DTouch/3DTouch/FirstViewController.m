//
//  FirstViewController.m
//  3DTouch
//
//  Created by 刘威成 on 16/5/18.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "FirstViewController.h"
#import "secondViewController.h"
#import "tableViewController.h"
@interface FirstViewController ()

@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeSystem];
    
    btn.frame = CGRectMake(100, 100, 100, 100);
    
    [btn setBackgroundColor:[UIColor blueColor]];
    
    [btn setTitle:@"下一页" forState:UIControlStateNormal];
    
    [btn  addTarget:self action:@selector(gotonext) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:btn];
    
    
    UIButton *btn2 = [UIButton buttonWithType:UIButtonTypeSystem];
    
    btn2.frame = CGRectMake(100, 320, 100, 100);
    
    [btn2 setBackgroundColor:[UIColor blueColor]];
    
    [btn2 setTitle:@"table-touch" forState:UIControlStateNormal];
    
    [btn2  addTarget:self action:@selector(gototableView) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:btn2];
}

- (void)gotonext{
    
    secondViewController *sec = [[secondViewController alloc]init];
    
    [self.navigationController pushViewController:sec animated:YES];
}

- (void)gototableView{
    
    tableViewController *tableView = [[tableViewController alloc]init];
    
    [self.navigationController pushViewController:tableView animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
