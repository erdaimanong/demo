//
//  FiveViewController.m
//  3DTouch
//
//  Created by 刘威成 on 16/5/18.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "FiveViewController.h"

@interface FiveViewController ()

@end

@implementation FiveViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake(100, 200, 200, 20)];
    
    lab.text = @"4.this's a demo for 3Dtouch";
    
    lab.textAlignment = NSTextAlignmentCenter;
    
    lab.font = [UIFont systemFontOfSize:14];
    
    [self.view addSubview:lab];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
