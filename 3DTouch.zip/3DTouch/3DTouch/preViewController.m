//
//  preViewController.m
//  3DTouch
//
//  Created by 刘威成 on 16/5/18.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "preViewController.h"

@interface preViewController ()

@property(nonatomic,strong)UILabel *lab;

@end

@implementation preViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    UILabel *lab = [[UILabel alloc]initWithFrame:CGRectMake(80, 100, 240, 20)];
    
    lab.text = self.textStr;
    
    lab.textAlignment = NSTextAlignmentLeft;
    
    [self.view addSubview:lab];
    
    
    
    _lab = [[UILabel alloc]initWithFrame:CGRectMake(80, 300, 240, 20)];
    
    _lab.text = @"3DTouch压力值的运用";
    
    _lab.textAlignment = NSTextAlignmentLeft;
    
    _lab.tag = 101;
    
    _lab.userInteractionEnabled = YES;
    
    [self.view addSubview:_lab];
}

- (NSArray<id<UIPreviewActionItem>> *)previewActionItems {
    // setup a list of preview actions
    UIPreviewAction *action1 = [UIPreviewAction actionWithTitle:@"Aciton1" style:UIPreviewActionStyleDefault handler:^(UIPreviewAction * _Nonnull action, UIViewController * _Nonnull previewViewController) {
        NSLog(@"Aciton1");
    }];
    
    UIPreviewAction *action2 = [UIPreviewAction actionWithTitle:@"Aciton2" style:UIPreviewActionStyleDefault handler:^(UIPreviewAction * _Nonnull action, UIViewController * _Nonnull previewViewController) {
        NSLog(@"Aciton2");
    }];
    
    UIPreviewAction *action3 = [UIPreviewAction actionWithTitle:@"Aciton3" style:UIPreviewActionStyleDefault handler:^(UIPreviewAction * _Nonnull action, UIViewController * _Nonnull previewViewController) {
        NSLog(@"Aciton3");
    }];
    
    NSArray *actions = @[action1,action2,action3];
    
    // and return them (return the array of actions instead to see all items ungrouped)
    return actions;
}

//3DTouch压力值的运用
//按住移动or压力值改变时的回调
-(void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event {
    
    NSArray *arrayTouch = [touches allObjects];
    
    UITouch *touch = (UITouch *)[arrayTouch lastObject];
    
    //通过tag确定按压的是哪个view，注意：如果按压的是label，将label的userInteractionEnabled属性设置为YES
    if (touch.view.tag == 101) {
        NSLog(@"move压力 ＝ %f",touch.force);
        //红色背景的label显示压力值
        _lab.text = [NSString stringWithFormat:@"压力%f",touch.force];
        //红色背景的label上移的高度＝压力值*100
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
