//
//  preViewController.h
//  3DTouch
//
//  Created by 刘威成 on 16/5/18.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface preViewController : UIViewController

@property(nonatomic,strong)NSString *textStr;

@end
