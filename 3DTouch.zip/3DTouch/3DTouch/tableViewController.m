//
//  tableViewController.m
//  3DTouch
//
//  Created by 刘威成 on 16/5/18.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "tableViewController.h"
#import "preViewController.h"
@interface tableViewController ()<UITableViewDelegate,UITableViewDataSource,UIViewControllerPreviewingDelegate>

@property(nonatomic,strong)UITableView *tableView;

@property(nonatomic,strong)NSArray *dataArr;

@end

@implementation tableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self createData];
    
    [self  createUI];
    
}

- (void)createUI{
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height-64) style:UITableViewStylePlain];
    
    _tableView.delegate = self;
    
    _tableView.dataSource = self;
    
    [self.view addSubview:_tableView];
    
}

- (void)createData{
    
 _dataArr = @[@"o",@"n",@"m",@"l",@"k",@"j",@"i",@"h",@"g",@"f",@"e",@"d",@"c",@"b",@"a"];
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return _dataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellID = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        
        cell.textLabel.text = _dataArr[indexPath.row];
        
        if (self.traitCollection.forceTouchCapability == UIForceTouchCapabilityAvailable) {
            NSLog(@"3D Touch  可用!");
            //给cell注册3DTouch的peek（预览）和pop功能
            [self registerForPreviewingWithDelegate:self sourceView:cell];
        } else {
            NSLog(@"3D Touch 无效");
        }
    }
    
    return cell;
}

//peek(预览)
- (nullable UIViewController *)previewingContext:(id <UIViewControllerPreviewing>)previewingContext viewControllerForLocation:(CGPoint)location
{
    //获取按压的cell所在行，[previewingContext sourceView]就是按压的那个视图
    NSIndexPath *indexPath = [_tableView indexPathForCell:(UITableViewCell* )[previewingContext sourceView]];
    
    //设定预览的界面
    
    preViewController *childVC = [[preViewController alloc]init];
    childVC.preferredContentSize = CGSizeMake(0.0f,500.0f);
    childVC.textStr = [NSString stringWithFormat:@"我是%@,用力按一下进来",_dataArr[indexPath.row]];
    
    //调整不被虚化的范围，按压的那个cell不被虚化（轻轻按压时周边会被虚化，再少用力展示预览，再加力跳页至设定界面）
    CGRect rect = CGRectMake(0, 0, self.view.frame.size.width,40);
    previewingContext.sourceRect = rect;
    
    //返回预览界面
    return childVC;
}

//pop（按用点力进入）
- (void)previewingContext:(id <UIViewControllerPreviewing>)previewingContext commitViewController:(UIViewController *)viewControllerToCommit {
    [self showViewController:viewControllerToCommit sender:self];
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    preViewController *preView = [[preViewController alloc]init];
    
    [self.navigationController pushViewController:preView animated:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
