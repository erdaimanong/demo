//
//  OnlyRectStyleViewController.h
//  二维码、条形码生成与扫描
//
//  Created by 刘威成 on 16/5/16.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "RootViewController.h"

@interface OnlyRectStyleViewController : RootViewController

@end
