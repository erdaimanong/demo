//
//  ViewController.m
//  二维码、条形码生成与扫描
//
//  Created by 刘威成 on 16/5/13.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "ViewController.h"

#import "QR_LogoViewController.h"

#import "QR_ColorViewController.h"

#import "QR_identityViewController.h"

#import "Origin_ScanViewController.h"

#import "Origin_ReaderViewController.h"

#import "Origin_CreatViewController.h"

#import "Origin_identifyViewController.h"

#import  "ZBar_ScanViewController.h"

#import "Zxing_scanViewController.h"

#import "Zxing_createViewController.h"

#import "Zxing_readerViewController.h"

#import "ScanUIViewController.h"
@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)UITableView *tableView;

@property(nonatomic,strong)NSArray *dataArr;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"类型";
    
    [self  createData];
    
    [self  creatUI];
}

-  (void)createData{
    
    _dataArr = @[@"QR生成带LOGO的二维码",@"QR生成可变色的二维码",@"QR长按识别二维码",@"原生二维码的扫描",@"原生二维码的读取",@"原生二维码的生成",@"原生长按识别二维码",@"ZBarSDK扫描二维码",@"ZXingOBJC扫描二维码",@"ZXingOBJC生成二维码",@"ZXingObjc读取二维码",@"各大平台扫码的效果"];
}

- (void)creatUI{
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
    
    _tableView.frame = CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height);
    
    _tableView.dataSource = self;
    
    _tableView.delegate = self;
    
    [self.view addSubview:_tableView];
    
}

#pragma mark -- tableViewDelegate\tableViewDatasource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return _dataArr.count;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString * cellID = @"cellID";
    
    UITableViewCell *cell  = [tableView  dequeueReusableCellWithIdentifier:cellID];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID];
        
        cell.textLabel.text = _dataArr[indexPath.row];
    }

    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 44;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == 0) {
        
        QR_LogoViewController  *qr_Logo = [[QR_LogoViewController alloc]init];
        
        qr_Logo.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:qr_Logo animated:YES];
        
        
    }else if (indexPath.row == 1){
        
        QR_ColorViewController * qr_Color = [[QR_ColorViewController alloc]init];
        
         qr_Color.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:qr_Color animated:YES];
        
    }else if (indexPath.row == 2){
        
        QR_identityViewController *qr_identify = [[QR_identityViewController alloc]init];
        
        qr_identify.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:qr_identify animated:YES];
        
    }else if (indexPath.row == 3){
        
        Origin_ScanViewController *Orgin_Scan = [[Origin_ScanViewController alloc]init];
        
        Orgin_Scan.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:Orgin_Scan animated:YES];
        
    }else if (indexPath.row == 4){
        
        Origin_ReaderViewController *Origin_reader = [[Origin_ReaderViewController alloc]init];

        Origin_reader.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:Origin_reader animated:YES];
        
    }else if (indexPath.row == 5){
        
        Origin_CreatViewController *Origin_creat = [[Origin_CreatViewController alloc]init];
        
        Origin_creat.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:Origin_creat animated:YES];

        
    }else if (indexPath.row == 6){
        
        Origin_identifyViewController *Origin_indetify = [[Origin_identifyViewController alloc]init];
        
        Origin_indetify.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:Origin_indetify animated:YES];
        
    }else if (indexPath.row == 7){
        
        ZBar_ScanViewController *Zbar_scarn = [[ZBar_ScanViewController alloc]init];
        
        Zbar_scarn.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:Zbar_scarn animated:YES];
        
        
    }else if (indexPath.row == 8){
        
        Zxing_scanViewController *ZXing_scan = [[Zxing_scanViewController alloc]init];
        
        ZXing_scan.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:ZXing_scan animated:YES];
        
    }else if (indexPath.row == 9){
        
        Zxing_createViewController *ZXing_create = [[Zxing_createViewController alloc]init];
        
        ZXing_create.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:ZXing_create animated:YES];
    }else if (indexPath.row == 10) {
        
        Zxing_readerViewController *ZXing_reader = [[Zxing_readerViewController alloc]init];
        
        ZXing_reader.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:ZXing_reader animated:YES];
    }else{
        
        ScanUIViewController *scanUI = [[ScanUIViewController alloc]init];
        
        scanUI.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:scanUI animated:YES];
    }

    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
