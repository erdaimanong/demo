//
//  ScanUIViewController.m
//  二维码、条形码生成与扫描
//
//  Created by 刘威成 on 16/5/16.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "ScanUIViewController.h"

#import "QQStyleViewController.h"

#import "ZhifubaoStyleViewController.h"

#import "WeiXinStyleViewController.h"

#import "InnerStyleViewController.h"

#import "OnStyleViewController.h"

#import "ChangeColorViewController.h"

#import "OnlyRectStyleViewController.h"

#import "ChangeSizeViewController.h"

#import "SquareStyleViewController.h"

#import "GoodsCodeStyleViewController.h"

#import "PayCodeStyleViewController.h"

@interface ScanUIViewController ()<UITableViewDelegate,UITableViewDataSource>

@property(nonatomic,strong)UITableView *tableView;

@property(nonatomic,strong)NSArray *dataArr;

@end

@implementation ScanUIViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self createData];
    
    [self createUI];
}

- (void)createUI{
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 64, KScreenWidth, KScreenHeight-64) style:UITableViewStylePlain];
    
    _tableView.delegate = self;
    
    _tableView.dataSource = self;
    
    [self.view addSubview:_tableView];
    
}

- (void)createData{
    
    _dataArr = @[@"仿QQ扫码界面",@"仿支付宝扫码界面",@"仿微信扫码区域",@"无边框、有四个角",@"网格动画有四角",@"自定义颜色",@"只识别框内",@"改变尺寸",@"条形码效果",@"商品条形码",@"支付宝付款条形码（code93）"];
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return _dataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *cellID = @"cellID";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID];
        
        cell.textLabel.text = self.dataArr[indexPath.row];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == 0) {
        
        QQStyleViewController *qqStyle = [[QQStyleViewController alloc]init];
        
        qqStyle.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:qqStyle animated:YES];
        
    }else if (indexPath.row ==1){
        
        ZhifubaoStyleViewController *zhiFubaoStyle = [[ZhifubaoStyleViewController alloc]init];
        
        zhiFubaoStyle.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:zhiFubaoStyle animated:YES];
        
    }else if (indexPath.row ==2){
        
        WeiXinStyleViewController *weixinStyle = [[WeiXinStyleViewController alloc]init];
        
        weixinStyle.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:weixinStyle animated:YES];
        
    }else if (indexPath.row ==3){
        
        InnerStyleViewController *inner = [[InnerStyleViewController alloc]init];
        
        inner.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:inner animated:YES];
        
    }else if (indexPath.row ==4){
        
        OnStyleViewController *Onstyle = [[OnStyleViewController alloc]init];
        
        Onstyle.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:Onstyle animated:YES];
        
    }else if (indexPath.row ==5){
        
        ChangeColorViewController *changecolor = [[ChangeColorViewController alloc]init];
        
        changecolor.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:changecolor animated:YES];
        
    }else if (indexPath.row ==6){
        
        OnlyRectStyleViewController *Onlyrect = [[OnlyRectStyleViewController alloc]init];
        
        Onlyrect.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:Onlyrect animated:YES];
        
    }else if (indexPath.row ==7){
        
        ChangeSizeViewController *changeSize = [[ChangeSizeViewController alloc]init];
        
        changeSize.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:changeSize animated:YES];
        
    }else if (indexPath.row ==8){
        
        SquareStyleViewController *square = [[SquareStyleViewController alloc]init];
        
        square.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:square animated:YES];
        
    }else if (indexPath.row ==9){
        
        GoodsCodeStyleViewController *goods = [[GoodsCodeStyleViewController alloc]init];
        
        goods.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:goods animated:YES];
        
    }else if (indexPath.row ==10){
        
        PayCodeStyleViewController *pay = [[PayCodeStyleViewController alloc]init];
        
        pay.navigationItem.title = self.dataArr[indexPath.row];
        
        [self.navigationController pushViewController:pay animated:YES];
        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
