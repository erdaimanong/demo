//
//  Origin_ScanViewController.m
//  二维码、条形码生成与扫描
//
//  Created by 刘威成 on 16/5/13.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "Origin_ScanViewController.h"

#import <AVFoundation/AVFoundation.h>

@interface Origin_ScanViewController ()<AVCaptureMetadataOutputObjectsDelegate>//用于处理采集信息的代理

@property (nonatomic, strong) AVCaptureSession *captureSession;

@property (nonatomic, strong) AVCaptureMetadataOutput *captureOutput;

@property (nonatomic, strong) UIImageView *sweepLineView;/**< 扫描条 */
@end

@implementation Origin_ScanViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    //主要判断有没有摄像设备、有没有权限使用摄像设备
    if (![self authJudge]) {
        return;
    }
    //获取摄像设备
    AVCaptureDevice  *captureDevice = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    //创建输入流
    AVCaptureDeviceInput *captureInput = [AVCaptureDeviceInput deviceInputWithDevice:captureDevice error:nil];
    //创建输出流
    self.captureOutput = [[AVCaptureMetadataOutput alloc] init];
    //设置代理 在主线程里刷新
    [_captureOutput setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    //初始化链接对象
    self.captureSession = [[AVCaptureSession alloc] init];
    //高质量采集率
    [_captureSession setSessionPreset:AVCaptureSessionPresetHigh];
    
    if ([_captureSession canAddInput:captureInput]) {
        [_captureSession addInput:captureInput];
    }
    
    if ([_captureSession canAddOutput:_captureOutput]) {
        [_captureSession addOutput:_captureOutput];
    }
    
    /**
     * //扫码类型
     
     @[AVMetadataObjectTypeQRCode,         //二维码
     
     AVMetadataObjectTypeCode39Code,     //条形码   韵达和申通
     
     AVMetadataObjectTypeCode128Code,    //CODE128条码  顺丰用的
     
     AVMetadataObjectTypeCode39Mod43Code,
     
     AVMetadataObjectTypeEAN13Code,
     
     AVMetadataObjectTypeEAN8Code,
     
     AVMetadataObjectTypeCode93Code,    //条形码,星号来表示起始符及终止符,如邮政EMS单上的条码
     
     AVMetadataObjectTypeUPCECode]];
     */
    //设置扫码支持的编码格式(如下设置条形码和二维码兼容)
    _captureOutput.metadataObjectTypes=@[AVMetadataObjectTypeQRCode,AVMetadataObjectTypeEAN13Code, AVMetadataObjectTypeEAN8Code, AVMetadataObjectTypeCode128Code];

    AVCaptureVideoPreviewLayer *previewLayer = [AVCaptureVideoPreviewLayer layerWithSession:_captureSession];
    previewLayer.frame = CGRectMake(0, 64, KScreenWidth, KScreenHeight - 64);
    previewLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    [self.view.layer addSublayer:previewLayer];
    
    //设置有效扫描区域 rectOfInterest是一个比例关系
    CGRect rect = CGRectMake(40, 120, KScreenWidth-80, KScreenWidth-80);
    _captureOutput.rectOfInterest = [previewLayer metadataOutputRectOfInterestForRect:rect];
    
    //开始捕获
    [_captureSession startRunning];
    
    //蒙版的大小
    UIView *maskView = [[UIView alloc] initWithFrame:CGRectMake(0, 64, KScreenWidth, KScreenHeight - 64)];
    maskView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.3];
    [self.view addSubview:maskView];
    
//    中间扫码区域的大小
    UIBezierPath *rectPath = [UIBezierPath bezierPathWithRect:CGRectMake(0, 0, KScreenWidth, KScreenHeight)];
    [rectPath appendPath:[[UIBezierPath bezierPathWithRoundedRect:CGRectMake(40, 120, KScreenWidth-80, KScreenWidth-80) cornerRadius:1] bezierPathByReversingPath]];
    CAShapeLayer *shapeLayer = [CAShapeLayer layer];
    shapeLayer.path = rectPath.CGPath;
    maskView.layer.mask = shapeLayer;
    
   //扫描有效区域的边框
    UIImageView *scanAreaImageView = [[UIImageView alloc] initWithFrame:CGRectMake(40, 120+64, KScreenWidth-80, KScreenWidth-80)];
//    scanAreaImageView.image = [UIImage imageNamed:@"scan_code_frame"];
    scanAreaImageView.layer.cornerRadius = 2;
    scanAreaImageView.layer.borderColor = [UIColor orangeColor].CGColor;
    scanAreaImageView.layer.borderWidth = 1;
    [self.view addSubview:scanAreaImageView];
    
    //中间的那个扫描线
    self.sweepLineView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 30, KScreenWidth-80-40, 2)];
//    _sweepLineView.image = [UIImage imageNamed:@"scan_code_line"];
    _sweepLineView.backgroundColor = [UIColor redColor];
    [scanAreaImageView addSubview:_sweepLineView];
    
    //开始动画
    [self sweepAnimation];
}


#pragma mark - Privite Methods
- (BOOL)authJudge {
    
    if ([[AVCaptureDevice devicesWithMediaType:AVMediaTypeVideo] count] <= 0) {
        NSLog(@"没有相机");
        return NO;
    }
    if([AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo] == AVAuthorizationStatusDenied) {
        NSLog(@"没有权限");
        return NO;
    }
    return YES;
}

- (void)sweepAnimation {
    //添加扫码动画
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:2.0f];
    [UIView setAnimationRepeatAutoreverses:YES];
    [UIView setAnimationRepeatCount:10000];
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    
    _sweepLineView.frame = CGRectMake(CGRectGetMinX(_sweepLineView.frame), 250, CGRectGetWidth(_sweepLineView.frame), CGRectGetHeight(_sweepLineView.frame));
    
    [UIView commitAnimations];
}



#pragma mark - Delegate
#pragma mark AVCaptureMetadataOutputObjectsDelegate
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection {
    
    if (metadataObjects.count > 0) {
        
        NSLog(@"%@",[[metadataObjects objectAtIndex:0] stringValue]);
        
        NSString *urlStr = [[metadataObjects objectAtIndex:0] stringValue];
        
        NSURL *url = [NSURL URLWithString:urlStr];
        
        if ([[UIApplication sharedApplication]canOpenURL:url]) {
            
            [[UIApplication sharedApplication]openURL:url];
        }
    }
}




#pragma makr - ReceiveMemoryWarn
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
