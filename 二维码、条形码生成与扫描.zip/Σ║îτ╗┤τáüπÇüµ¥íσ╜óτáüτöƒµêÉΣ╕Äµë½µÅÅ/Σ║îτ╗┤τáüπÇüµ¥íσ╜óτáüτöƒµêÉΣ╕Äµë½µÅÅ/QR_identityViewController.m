//
//  QR_identityViewController.m
//  二维码、条形码生成与扫描
//
//  Created by 刘威成 on 16/5/14.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "QR_identityViewController.h"

#import "QRCodeGenerator.h"

@interface QR_identityViewController ()

@property(nonatomic,strong)UIImageView *outImageView;

@end

@implementation QR_identityViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    _outImageView=[[UIImageView alloc]initWithFrame:CGRectMake(40, 100, KScreenWidth-80, KScreenWidth-80)];
    _outImageView.layer.borderWidth=2.0f;
    _outImageView.layer.borderColor=[UIColor redColor].CGColor;
    _outImageView.userInteractionEnabled=YES;
    UIImage *image=[UIImage imageNamed:@"QR-icon"];
    UIImage*tempImage=[QRCodeGenerator qrImageForString:@"https://www.juzhong.cn/borrow/detail/800" imageSize:360 Topimg:image withColor:[UIColor blackColor]];
    _outImageView.image=tempImage;
    UILongPressGestureRecognizer*longPress=[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(dealLongPress:)];
    [_outImageView addGestureRecognizer:longPress];
    [self.view addSubview:_outImageView];
}

#pragma mark-> 长按识别二维码
-(void)dealLongPress:(UIGestureRecognizer*)gesture{
    
    if(gesture.state==UIGestureRecognizerStateBegan){
        
        UIImageView*tempImageView=(UIImageView*)gesture.view;
        if(tempImageView.image){
            //1. 初始化扫描仪，设置设别类型和识别质量
            CIDetector*detector = [CIDetector detectorOfType:CIDetectorTypeQRCode context:nil options:@{ CIDetectorAccuracy : CIDetectorAccuracyHigh }];
            //2. 扫描获取的特征组
            NSArray *features = [detector featuresInImage:[CIImage imageWithCGImage:tempImageView.image.CGImage]];
            //3. 获取扫描结果
            CIQRCodeFeature *feature = [features objectAtIndex:0];
            NSString *scannedResult = feature.messageString;
            UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"扫描结果" message:scannedResult delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertView show];
        }else {
            
            UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"扫描结果" message:@"您还没有生成二维码" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertView show];
        }
        
        
    }else if (gesture.state==UIGestureRecognizerStateEnded){
        
        
    }
    
    
}



@end
