//
//  Origin_creatViewController.m
//  二维码、条形码生成与扫描
//
//  Created by 刘威成 on 16/5/13.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "Origin_CreatViewController.h"

@interface Origin_CreatViewController ()

@property(nonatomic,strong)UIImageView *imageView;

@end

@implementation Origin_CreatViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIImageView *imageViews = [[UIImageView alloc]initWithFrame:CGRectMake(40, 120, KScreenWidth-80, KScreenWidth-80)];
    
    UIImage *image = [self generateQRCode:@"https://www.juzhong.cn/borrow/detail/978" width:KScreenWidth-80 height:KScreenWidth-80];
    
    imageViews.image =image;
    
    [self.view addSubview:imageViews];
    
    UIImageView *logoimage = [[UIImageView alloc]initWithFrame:CGRectMake((KScreenWidth-80)/2-30, (KScreenWidth-80)/2-30, 60, 60)];
    logoimage.image = [UIImage imageNamed:@"QR-icon"];
    
    [imageViews  addSubview:logoimage];
    
}

//生成二维码
- (UIImage *)generateQRCode:(NSString *)str width:(CGFloat)width height:(CGFloat)height {
    
    // 生成二维码图片
    CIImage *qrcodeImage;
    NSData *data = [str dataUsingEncoding:NSISOLatin1StringEncoding allowLossyConversion:false];
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    
    [filter setValue:data forKey:@"inputMessage"];
    [filter setValue:@"H" forKey:@"inputCorrectionLevel"];
    qrcodeImage = [filter outputImage];
    
    // 消除模糊
    CGFloat scaleX = width / qrcodeImage.extent.size.width; // extent 返回图片的frame
    CGFloat scaleY = height / qrcodeImage.extent.size.height;
    CIImage *transformedImage = [qrcodeImage imageByApplyingTransform:CGAffineTransformScale(CGAffineTransformIdentity, scaleX, scaleY)];
    
    return [UIImage imageWithCIImage:transformedImage];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
