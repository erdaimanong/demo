//
//  Zxing_scanViewController.m
//  二维码、条形码生成与扫描
//
//  Created by 刘威成 on 16/5/13.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "Zxing_scanViewController.h"
#import <ZXingObjC.h>
#import <AudioToolbox/AudioToolbox.h>

@interface Zxing_scanViewController () <ZXCaptureDelegate>

@property (nonatomic,strong) UIImageView *centerView;
@property (nonatomic,strong) ZXCapture *capture;

@end

@implementation Zxing_scanViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.centerView=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 200, 200)];
    self.centerView.backgroundColor=[UIColor colorWithRed:0.5 green:0.5 blue:0.5 alpha:0.1];
    self.centerView.center=self.view.center;
    [self.view addSubview:self.centerView];
    
    self.capture = [[ZXCapture alloc] init];
    self.capture.camera = self.capture.back;
    self.capture.focusMode = AVCaptureFocusModeContinuousAutoFocus;
    self.capture.rotation = 90.0f;
    self.capture.layer.frame = self.view.bounds;
    [self.view.layer addSublayer:self.capture.layer];
    
    [self.view bringSubviewToFront:self.centerView];
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    self.capture.delegate = self;
    self.capture.layer.frame = self.view.bounds;
    
    CGAffineTransform captureSizeTransform = CGAffineTransformMakeScale(320 / KScreenWidth, 480 / KScreenHeight);
    self.capture.scanRect = CGRectApplyAffineTransform(self.centerView.frame, captureSizeTransform);
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation {
    return toInterfaceOrientation == UIInterfaceOrientationPortrait;
}

- (NSString *)barcodeFormatToString:(ZXBarcodeFormat)format {
    switch (format) {
        case kBarcodeFormatAztec:
            return @"Aztec";
        case kBarcodeFormatCodabar:
            return @"CODABAR";
        case kBarcodeFormatCode39:
            return @"Code 39";
        case kBarcodeFormatCode93:
            return @"Code 93";
        case kBarcodeFormatCode128:
            return @"Code 128";
        case kBarcodeFormatDataMatrix:
            return @"Data Matrix";
        case kBarcodeFormatEan8:
            return @"EAN-8";
        case kBarcodeFormatEan13:
            return @"EAN-13";
        case kBarcodeFormatITF:
            return @"ITF";
        case kBarcodeFormatPDF417:
            return @"PDF417";
        case kBarcodeFormatQRCode:
            return @"QR Code";
        case kBarcodeFormatRSS14:
            return @"RSS 14";
        case kBarcodeFormatRSSExpanded:
            return @"RSS Expanded";
        case kBarcodeFormatUPCA:
            return @"UPCA";
        case kBarcodeFormatUPCE:
            return @"UPCE";
        case kBarcodeFormatUPCEANExtension:
            return @"UPC/EAN extension";
        default:
            return @"Unknown";
    }
}

- (void)captureResult:(ZXCapture *)capture result:(ZXResult *)result {
    if (!result){
        return;
    }
    
    NSString *formatString = [self barcodeFormatToString:result.barcodeFormat];
    NSLog(@"%@",[NSString stringWithFormat:@"条码格式:%@ \n内容:%@", formatString, result.text]);
    [self.capture stop];
    //震动提示
    AudioServicesPlaySystemSound(kSystemSoundID_Vibrate);
}


@end
