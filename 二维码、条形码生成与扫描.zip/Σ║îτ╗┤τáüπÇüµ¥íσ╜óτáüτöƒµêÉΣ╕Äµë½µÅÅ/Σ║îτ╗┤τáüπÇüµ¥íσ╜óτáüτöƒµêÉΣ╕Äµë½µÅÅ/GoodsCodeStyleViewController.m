//
//  GoodsCodeStyleViewController.m
//  二维码、条形码生成与扫描
//
//  Created by 刘威成 on 16/5/16.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "GoodsCodeStyleViewController.h"
#import "LBXScanWrapper.h"
@interface GoodsCodeStyleViewController ()

@property (nonatomic, strong) UIView *tView;
@property (nonatomic, strong) UIImageView *tImgView;

@end

@implementation GoodsCodeStyleViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    //条形码
    self.tView = [[UIView alloc]initWithFrame:CGRectMake( (CGRectGetWidth(self.view.frame)-CGRectGetWidth(self.view.frame)*5/6)/2,
                                                         100,
                                                         CGRectGetWidth(self.view.frame)*5/6,
                                                         CGRectGetWidth(self.view.frame)*5/6*0.5)];
    [self.view addSubview:_tView];
    
    
    self.tImgView = [[UIImageView alloc]init];
    _tImgView.bounds = CGRectMake(0, 0, CGRectGetWidth(_tView.frame)-12, CGRectGetHeight(_tView.frame)-12);
    _tImgView.center = CGPointMake(CGRectGetWidth(_tView.frame)/2, CGRectGetHeight(_tView.frame)/2);
    [_tView addSubview:_tImgView];
    
    
    [self createCodeEAN13];
}
//商品条形码
- (void)createCodeEAN13
{
//    _qrView.hidden = YES;
    _tView.hidden = NO;
    
    _tImgView.image = [LBXScanWrapper createCodeWithString:@"6944551723107" size:_tImgView.bounds.size CodeFomart:AVMetadataObjectTypeEAN13Code];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
