//
//  QR_LogoViewController.m
//  二维码、条形码生成与扫描
//
//  Created by 刘威成 on 16/5/13.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "QR_LogoViewController.h"

#import "QRCodeGenerator.h"

@interface QR_LogoViewController ()

@property (nonatomic,strong) UIImageView *erWeiCode;

@end

@implementation QR_LogoViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self  createUI];
}

- (void)createUI{

    _erWeiCode = [[UIImageView alloc]initWithFrame:CGRectMake(40, 100, KScreenWidth-80, KScreenWidth-80)];
    [self.view addSubview:_erWeiCode];
    _erWeiCode.backgroundColor = [UIColor whiteColor];
    _erWeiCode.layer.masksToBounds = YES;
    _erWeiCode.layer.cornerRadius = 10;
    
    UIImage *image=[UIImage imageNamed:@"QR-icon"];
    
    NSString*tempStr = @"https://www.juzhong.cn/borrow/detail/800";
    
    UIImage *tempImage=[QRCodeGenerator qrImageForString:tempStr imageSize:KScreenWidth-60 Topimg:image];
    
    _erWeiCode.image=tempImage;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
