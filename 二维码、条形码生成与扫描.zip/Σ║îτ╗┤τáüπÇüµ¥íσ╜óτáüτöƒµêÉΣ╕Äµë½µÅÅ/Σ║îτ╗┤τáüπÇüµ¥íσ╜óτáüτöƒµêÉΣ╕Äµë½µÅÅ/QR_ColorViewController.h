//
//  QR_ColorViewController.h
//  二维码、条形码生成与扫描
//
//  Created by 刘威成 on 16/5/13.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QR_ColorViewController : UIViewController

@end
