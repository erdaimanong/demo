//
//  Zxing_createViewController.m
//  二维码、条形码生成与扫描
//
//  Created by 刘威成 on 16/5/15.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "Zxing_createViewController.h"

#import <ZXingObjC/ZXingObjC.h>

@interface Zxing_createViewController ()

@end

@implementation Zxing_createViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIImageView *imageViews = [[UIImageView alloc]initWithFrame:CGRectMake(40, 120, KScreenWidth-80, KScreenWidth-80)];

    
    ZXMultiFormatWriter *writer = [ZXMultiFormatWriter writer];
    ZXBitMatrix* result = [writer encode:@"https://www.juzhong.cn/borrow/detail/978"
                                  format:kBarcodeFormatQRCode
                                   width:KScreenWidth-80
                                  height:KScreenWidth-80
                                   error:nil];//err 不写了
    
    CGImageRef image = [[ZXImage imageWithMatrix:result] cgimage];
    UIImage *qrImage = [UIImage imageWithCGImage:image];

     imageViews.image =qrImage;
    
    [self.view addSubview:imageViews];
    
    
    //如果这个logo过大的话会扫描不出来、这给二维码的质量、误差率有关
    UIImageView *logoimage = [[UIImageView alloc]initWithFrame:CGRectMake((KScreenWidth-80)/2-20, (KScreenWidth-80)/2-20, 40, 40)];
    logoimage.image = [UIImage imageNamed:@"QR-icon"];
    
    [imageViews  addSubview:logoimage];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
