//
//  Origin_identifyViewController.m
//  二维码、条形码生成与扫描
//
//  Created by 刘威成 on 16/5/14.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "Origin_identifyViewController.h"



@interface Origin_identifyViewController ()

@property(nonatomic,strong)UIImageView *imageView;
@property(nonatomic,strong)UIImageView *logoimage;
@property(nonatomic,strong)UIImage *image;
@end

@implementation Origin_identifyViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    _imageView = [[UIImageView alloc]initWithFrame:CGRectMake(40, 120, KScreenWidth-80, KScreenWidth-80)];
    
    _imageView.backgroundColor = [UIColor whiteColor];
    _imageView.layer.masksToBounds = YES;
    _imageView.layer.cornerRadius = 10;
    _imageView.layer.borderColor = [UIColor orangeColor].CGColor;
    _imageView.layer.borderWidth = 1;
    
    _imageView.userInteractionEnabled  = YES;
    
    UILongPressGestureRecognizer*longPress=[[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(dealLongPress:)];
    
    [_imageView addGestureRecognizer:longPress];
    
    _image = [self generateQRCode:@"https://www.juzhong.cn/borrow/detail/978" width:KScreenWidth-80 height:KScreenWidth-80];
    
    _imageView.image =_image;
    
    _logoimage = [[UIImageView alloc]initWithFrame:CGRectMake((KScreenWidth-80)/2-30, (KScreenWidth-80)/2-30, 60, 60)];
    _logoimage.image = [UIImage imageNamed:@"QR-icon"];

    [_imageView  addSubview:_logoimage];

    
    [self.view addSubview:_imageView];

}

//生成二维码
- (UIImage *)generateQRCode:(NSString *)str width:(CGFloat)width height:(CGFloat)height {
    
    // 生成二维码图片
    CIImage *qrcodeImage;
    NSData *data = [str dataUsingEncoding:NSISOLatin1StringEncoding allowLossyConversion:false];
    CIFilter *filter = [CIFilter filterWithName:@"CIQRCodeGenerator"];
    
    [filter setValue:data forKey:@"inputMessage"];
    [filter setValue:@"H" forKey:@"inputCorrectionLevel"];
    qrcodeImage = [filter outputImage];
    
    // 消除模糊
    CGFloat scaleX = width / qrcodeImage.extent.size.width; // extent 返回图片的frame
    CGFloat scaleY = height / qrcodeImage.extent.size.height;
    CIImage *transformedImage = [qrcodeImage imageByApplyingTransform:CGAffineTransformScale(CGAffineTransformIdentity, scaleX, scaleY)];
    
    return [UIImage imageWithCIImage:transformedImage];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#warning 提示 如果crash、可能CIDetector只能支持相册的图片二维码、在pad上面没有问题、但是iPhone上不行（即使IOS8later、iphone5以后的设备、网上也没有找到问题的所在 思路：如果非要实现长按识别二维码、考虑用QR生成、然后同样的方法识别

#pragma mark-> 长按识别二维码
-(void)dealLongPress:(UIGestureRecognizer*)gesture{
    
    if(gesture.state == UIGestureRecognizerStateBegan){
        
        UIImageView*tempImageView = _imageView;
        
        if(tempImageView.image){
            //1. 初始化扫描仪，设置设别类型和识别质量
            CIDetector*detector = [CIDetector detectorOfType:CIDetectorTypeQRCode context:nil options:@{ CIDetectorAccuracy : CIDetectorAccuracyHigh }];
            //2. 扫描获取的特征组
            
            NSArray *features = [detector featuresInImage:[CIImage imageWithCGImage:tempImageView.image.CGImage]];
            //3. 获取扫描结果
            CIQRCodeFeature *feature = [features objectAtIndex:0];
            NSString *scannedResult = feature.messageString;
            UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"扫描结果" message:scannedResult delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertView show];
        }else {
            
            UIAlertView * alertView = [[UIAlertView alloc]initWithTitle:@"扫描结果" message:@"您还没有生成二维码" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alertView show];
        }
        
    }else if (gesture.state==UIGestureRecognizerStateEnded){
        
        
//        _timer.fireDate=[NSDate distantPast];
    }
    
    
}


@end
