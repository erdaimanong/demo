//
//  ViewController.m
//  获取SIM卡信息
//
//  Created by 刘威成 on 16/3/8.
//  Copyright © 2016年 刘威成. All rights reserved.
//

/*
iphone获取sim卡信息

1.加入一个Framework(CoreTelephony.framework).

2.引入头文件

#import <CoreTelephony/CTTelephonyNetworkInfo.h>

#import <CoreTelephony/CTCarrier.h>

3.初始化

*/


#import "ViewController.h"

#import <CoreTelephony/CTTelephonyNetworkInfo.h>

#import <CoreTelephony/CTCarrier.h>

/**
 *  检测是否有SIM卡
 * [CTSIMSupportGetSIMStatus() isEqualToString:kCTSIMSupportSIMStatusNotInserted]
 */
extern NSString* const kCTSMSMessageReceivedNotification;
extern NSString* const kCTSMSMessageReplaceReceivedNotification;
extern NSString* const kCTSIMSupportSIMStatusNotInserted;   // 为插入SIM卡
extern NSString* const kCTSIMSupportSIMStatusReady;         // 已插入SIM卡


@interface ViewController ()<UITableViewDataSource,UITableViewDelegate>
{//声明变量
    
CTTelephonyNetworkInfo *networkInfo;
    
    UITableView *tableViews;
    
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.navigationItem.prompt = @"CTTelephonyNetworkInfo";
    
    self.navigationItem.title = @"CTCarrier";
    
    [self  initNetworkInfo];
    
    [self  createTableView];
    
    [self  haveSimCard];
    
    }
- (void)haveSimCard{

}

- (void)initNetworkInfo{
    
    //初始化
    
    networkInfo = [[CTTelephonyNetworkInfo alloc] init];
    
    //当sim卡更换时弹出此窗口
    
    networkInfo.subscriberCellularProviderDidUpdateNotifier = ^(CTCarrier *carrier){
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"Sim card changed" delegate:nil cancelButtonTitle:@"取消" otherButtonTitles:nil];
        
        [alert show];
        
    };
}

- (void)createTableView{
    
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    tableViews= [[UITableView alloc]initWithFrame:CGRectMake(0,84, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStylePlain];
    
    tableViews.delegate                     = self;
    
    tableViews.dataSource                   = self;
    
    tableViews.showsVerticalScrollIndicator = NO;
    
    tableViews.separatorStyle               = UITableViewCellSeparatorStyleNone;
    
    [self.view addSubview:tableViews];
}

#pragma mark -<UITableViewDataSource,UITableViewDelegate>

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  7;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //获取sim卡信息
    
    CTCarrier *carrier = networkInfo.subscriberCellularProvider;
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    if (cell == nil) {
        
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    switch (indexPath.row) {
            
        case 0://供应商名称（中国联通 中国移动）
            
            cell.textLabel.text = @"carrierName";
            
            cell.detailTextLabel.text = carrier.carrierName;
            
            break;
            
        case 1://所在国家编号
            
            cell.textLabel.text = @"所在国家编号";
            
            cell.detailTextLabel.text = carrier.mobileCountryCode;
            
            break;
            
        case 2://供应商网络编号
            
            cell.textLabel.text = @"供应商网络编号";
            
            cell.detailTextLabel.text = carrier.mobileNetworkCode;
            
            break;
            
        case 3:
            
            cell.textLabel.text = @"isoCountryCode";
            
            cell.detailTextLabel.text = carrier.isoCountryCode;
            
            break;
            
        case 4://是否允许voip
            
            cell.textLabel.text = @"allowsVOIP";
            
            cell.detailTextLabel.text = carrier.allowsVOIP?@"YES":@"NO";
            
            break;
            
            case 5: //    获取手机号码  只能获取的是机主设置的本机号码，不能读取sim卡上的电话号码
            cell.textLabel.text = @"本机号码";
           
            cell.detailTextLabel.text = [[NSUserDefaults standardUserDefaults] stringForKey:@"SBFormattedPhoneNumber"];
            
            break;
            
        case 6: //    获取手机号码  只能获取的是机主设置的本机号码，不能读取sim卡上的电话号码
            cell.textLabel.text = @"是否插入了sim卡";
            //检查是否插入sim卡
            
            //iOS中判断是否存在SIM卡
            id CTTelephonyCenterGetDefault(void);
            void CTTelephonyCenterAddObserver(id,id,CFNotificationCallback,NSString*,void*,int);
            void CTTelephonyCenterRemoveObserver(id,id,NSString*,void*);
            int CTSMSMessageGetUnreadCount(void);
            
            int CTSMSMessageGetRecordIdentifier(void * msg);
            NSString * CTSIMSupportGetSIMStatus();
            NSString * CTSIMSupportCopyMobileSubscriberIdentity();
            
            id  CTSMSMessageCreate(void* unknow/*always 0*/,NSString* number,NSString* text);
            void * CTSMSMessageCreateReply(void* unknow/*always 0*/,void * forwardTo,NSString* text);
            
            void* CTSMSMessageSend(id server,id msg);
            
            NSString *CTSMSMessageCopyAddress(void *, void *);
            NSString *CTSMSMessageCopyText(void *, void *);
            
            if([CTSIMSupportGetSIMStatus() isEqualToString:kCTSIMSupportSIMStatusNotInserted]){
              
                   cell.detailTextLabel.text = @"sim卡不存在";
                
            }else{
                   cell.detailTextLabel.text = @"已插入sim卡";
            }

            break;
            
        default:
            
            break;
            
    }
    return cell;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

    
    
    
