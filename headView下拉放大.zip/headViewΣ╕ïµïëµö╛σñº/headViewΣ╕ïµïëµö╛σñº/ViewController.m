//
//  ViewController.m
//  headView下拉放大
//
//  Created by 刘威成 on 16/4/7.
//  Copyright © 2016年 刘威成. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()<UITableViewDelegate , UITableViewDataSource>
//图片和tableView
@property (nonatomic , retain) UIImageView *imageView;
@property (nonatomic , retain) UITableView *tableView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    //设置imageView属性
    self.imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"04.jpg"]];
    //y值设置为－300 和下面设置tableView的偏移量（contentInset）是为了让图片显示一半
    self.imageView.frame = CGRectMake(0, -300, self.view.frame.size.width, 300);
    //这个属性是控制图片等比例放大缩小
    //contentMode是枚举属性，还有别的效果
    self.imageView.contentMode  = UIViewContentModeScaleAspectFill;
    self.tableView = [[UITableView alloc] initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    //设置偏移量
    self.tableView.contentInset = UIEdgeInsetsMake(150, 0, 0, 0);
    [self.view addSubview:self.tableView];
    [self.tableView insertSubview:self.imageView atIndex:0];
    
}
#pragma mark - tableView的代理方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 100;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellId = @"id";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellId];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellId];
    }
    
    cell.textLabel.text = [NSString stringWithFormat:@"测试数据%ld" , indexPath.row];
    return cell;
}



#pragma mark - 控制tableView中imageView的放大
//tableView是scrollView的子类


-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    //tableView下拉，根据偏移量计算出下拉的高度
    CGFloat downHeight = -scrollView.contentOffset.y - 150;
    
    NSLog(@"%f", downHeight);
    
    CGRect frame = self.imageView.frame;
    
    if (downHeight < 0) {
        
        frame.size.height = 300 + 150;
        self.imageView.frame = frame;
        
    }else if (downHeight<150){
        
        //根据下拉高度计算图片拉伸的高度
        frame.size.height = 300 + downHeight;
        self.imageView.frame = frame;
        
    }else{
        frame.size.height = 300 + 150;
        self.imageView.frame = frame;
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
